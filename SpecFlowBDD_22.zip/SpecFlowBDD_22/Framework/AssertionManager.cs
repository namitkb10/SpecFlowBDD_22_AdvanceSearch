﻿using NUnit.Framework;
using OpenQA.Selenium;
using SpecFlowBDD_22.HooksManager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpecFlowBDD_22.Framework
{
    public class AssertionManager
    {
        static WaitManager wait = new WaitManager();

        public static void ElementTextEquals(IWebElement element, String expectedtext)
        {
            //wait.UntilTextToBePresentInElement(element, expectedtext);
            Assert.AreEqual(expectedtext, element.Text.Trim(), "Text does not match -> Actual: " + element.Text + " Expected: " + expectedtext);
        }

        public static void ListValuesAreEquals(List<string> expectedList, List<string> listValue)
        {
            Assert.AreEqual(expectedList, listValue, "List values mismatched");
        }
        public static void ElementTextContains(IWebElement element, String expectedtext)
        {
            Assert.IsTrue(element.Text.Contains(expectedtext), "Text does not match -> Actual: " + element.Text + " Expected: " + expectedtext);
        }

        public static void IsTrue(bool value)
        {
            Assert.IsTrue(value);
        }


        public static void ElementValueEquals(IWebElement element, String expectedvalue)
        {
            wait.UntilValueToBePresentInElement(element, expectedvalue);
            Assert.AreEqual(expectedvalue, element.GetAttribute("value").Trim(), "Value does not match -> Actual: " + element.GetAttribute("value") + " Expected: " + expectedvalue);
        }

        public static void ElementGetAttribute(IWebElement element, String attribute, String expectedvalue)
        {
            Assert.AreEqual(expectedvalue, element.GetAttribute(attribute), "Value does not match -> Actual: " + element.GetAttribute(attribute) + " Expected: " + expectedvalue);
        }

        public static void ElementGetReadonlyAttribute(IWebElement element, string expectedvalue)
        {
            Assert.AreEqual(expectedvalue, element.GetAttribute("readonly"), "Value does not match -> Actual: " + element.GetAttribute("readonly") + " Expected: " + expectedvalue);
        }

        public static void ElementTextNotEquals(IWebElement element, String expectedtext)
        {
            Assert.AreNotEqual(expectedtext, element.Text, "Text matched -> Actual: " + element.Text + " Expected: " + expectedtext);
        }

        public static void Present(IWebElement element)
        {
            Assert.IsTrue(element.Displayed, "Following element was not displayed : " + element);
        }
        public static void Enabled(IWebElement element)
        {
            Assert.IsTrue(element.Enabled, "Following element was disabled : " + element);
        }

        public static void Checked(IWebElement element)
        {
            Assert.IsTrue(element.Selected, "Following element was not checked : " + element);
        }
        public static void UnChecked(IWebElement element)
        {
            Assert.IsFalse(element.Selected, "Following element was checked : " + element);
        }
        public static void Disabled(IWebElement element)
        {
            Assert.IsFalse(element.Enabled, "Following element was enabled : " + element);
        }

        public static void Displayed(IWebElement element)
        {
            Assert.IsTrue(element.Displayed, "Following element was not displayed: " + element);
        }

        public static void NotDisplayed(IWebElement element)
        {
            Assert.IsFalse(element.Displayed, "Following element was displayed: " + element);
        }

        public static void ElementNotPresent(IWebElement element)
        {
            bool result = false;
            try
            {
                if (element.Displayed)
                {
                    result = true;
                }
            }
            catch
            {
            }

            if (result == true)
            {
                throw new Exception("Error : Element Still Exists");
            }
        }

        public static void ElementNotVisible(string value)
        {
            bool result = false;
            try
            {
                IWebElement element = HooksSpecFlow.driver.FindElement(By.XPath(value));
            }
            catch
            {
                result = true;
            }

            if (result == false)
            {
                throw new Exception("Error : Element Still Exists");
            }
        }

        public static void ElementVisible(string value)
        {
            bool result = false;
            try
            {
                IWebElement element = HooksSpecFlow.driver.FindElement(By.XPath(value));
                result = true;
            }
            catch
            {
            }

            if (result == false)
            {
                throw new Exception("Error : Element Not Exists");
            }
        }

        public static void CompareAttributeValue(IWebElement element, string attribute, string value)
        {
            Assert.AreEqual(value, element.GetAttribute(attribute), "Following attributes values does not match : Expected : " + value + " + Actual : " + element.GetAttribute(attribute));
        }

        public static void Selected(IWebElement element)
        {
            Assert.IsTrue(element.Selected, "Following element was not selected : " + element);
        }

        public static void Fail(String ErrorMessage)
        {
            Assert.Fail(ErrorMessage);
        }

        /// <summary>
        /// Method for verifying attribute value is present
        /// </summary>
        public static void HtmlAttributeValue(IWebElement element, string attributeType, string attributeValue)
        {
            try
            {
                if (!element.GetAttribute(attributeType).Contains(attributeValue))
                {
                    throw new Exception(string.Format("Error : Attribute value is not present"));
                }
            }
            catch
            {
                throw new Exception(string.Format("Error : Attribute type or value is not present"));
            }
        }

        /// <summary>
        /// Method for verifying attribute value is not present
        /// </summary>
        public static void HtmlAttributeValueNotPresent(IWebElement element, string attributeType, string attributeValue)
        {
            try
            {
                if (element.GetAttribute(attributeType).Contains(attributeValue))
                {
                    throw new Exception(string.Format("Error : Attribute value is present"));
                }
            }
            catch
            {
            }
        }

        /// <summary>
        /// Method to verify downloaded file is present or not
        /// </summary>
        public static void FileExists(string fileName)
        {
            string userPath = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            string downloadPath = Path.Combine(userPath, "Downloads");
            if ((File.Exists(downloadPath + "\\" + fileName)) == false)
            {
                throw new Exception("File not exist");
            }
        }
    }
}
