﻿using BoDi;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Edge;
using System.ComponentModel;
using TechTalk.SpecFlow;
using WebDriverManager.DriverConfigs.Impl;
using WindowsInput;
using WindowsInput.Native;
using SpecFlowBDD_22.CommonClass;
using OpenQA.Selenium.Firefox;
using System.Data.SqlClient;
using SpecFlowBDD_22.Framework;

namespace SpecFlowBDD_22.HooksManager
{
    [Binding]
    public sealed class HooksSpecFlow
    {
        // For additional details on SpecFlow hooks see http://go.specflow.org/doc-hooks
        public static string servicesAppPortal = "Data Source=10.75.205.8;Initial Catalog=Gls_app;Integrated Security=True;";
        public static SqlConnection connectAppPortal;
        public static IWebDriver? driver;
        InputSimulator inputSim = new InputSimulator();
        ClassCommon cc = new ClassCommon();
        // "@tag1"

        private IObjectContainer _container=null;
        public HooksSpecFlow(IObjectContainer container)
        {
            _container = container;
        }

        /*[BeforeTestRun]
        public static void BeforeTestRun()
        {
           Console.WriteLine("Started Before Test Run...");

            new WebDriverManager.DriverManager().SetUpDriver(new ChromeConfig());
            driver = new ChromeDriver();

            // new WebDriverManager.DriverManager().SetUpDriver(new EdgeConfig());
            // driver = new EdgeDriver();

            driver.Manage().Window.Maximize();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
            driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(30);

            //_container.RegisterInstanceAs<IWebDriver>(driver);

            // Login Code

            Thread.Sleep(3000);

            // driver.Navigate().GoToUrl("http://10.75.204.205/esd");

            // Testing URL
            driver.Navigate().GoToUrl("http://10.75.205.122/esd/");

            Thread.Sleep(3000);

            // Enter username
            inputSim.Keyboard.TextEntry("appportal\\appportal");
            Thread.Sleep(1000);
            // press Tab key 
            inputSim.Keyboard.KeyPress(VirtualKeyCode.TAB);
            Thread.Sleep(1000);
            // Enter Password 
            inputSim.Keyboard.TextEntry("Flexera!");
            Thread.Sleep(4000);
            // Click on Sign In button 
            // inputSim.Keyboard.KeyPress(VirtualKeyCode.TAB);
            // inputSim.Keyboard.KeyPress(VirtualKeyCode.TAB);
            // inputSim.Keyboard.KeyPress(VirtualKeyCode.TAB);

            inputSim.Keyboard.KeyPress(VirtualKeyCode.RETURN);
            Thread.Sleep(15000);
            Assert.True(driver.Title.Contains("Flexera Software App Portal"));

            Console.WriteLine("Authentication Pop-up Login Completed through hooks");
            // Make this instance available to all other step definitions
            //container.RegisterInstance(driver);
            // _container.RegisterInstanceAs<IWebDriver>(driver);

            _container.RegisterInstanceAs<IWebDriver>(driver);

        }

        [AfterTestRun]
        public static void AfterTestRun()
        {
            //TODO: implement logic that has to run after executing each scenario
            Console.WriteLine("Running after scenario...");
            var driver = _container.Resolve<IWebDriver>();

            Console.WriteLine("After Scenario driver value is: " + driver);

            *//*if (driver != null)
            {
                driver.Quit();
            }*//*
        }*/

        /*[BeforeFeature]
        public void BeforeFeature()
        {
            Console.WriteLine("Started before feature...");
            if (cc.getDataFromFile("browser") == "chrome")
            {
                new WebDriverManager.DriverManager().SetUpDriver(new ChromeConfig());
                driver = new ChromeDriver();
            }
            else if (cc.getDataFromFile("browser") == "edge")
            {
                new WebDriverManager.DriverManager().SetUpDriver(new EdgeConfig());
                driver = new EdgeDriver();
            }
            else if (cc.getDataFromFile("browser") == "firefox")
            {
                new WebDriverManager.DriverManager().SetUpDriver(new FirefoxConfig());
                driver = new FirefoxDriver();
            }
            else
            {
                Console.WriteLine("Not a valid browser name");
            }

            driver.Manage().Window.Maximize();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
            driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(30);

            //_container.RegisterInstanceAs<IWebDriver>(driver);

            // Login Code

            Thread.Sleep(3000);

            // driver.Navigate().GoToUrl("http://10.75.204.205/esd");

            // Testing URL
            String launchingURL = cc.getDataFromFile("url");
            // driver.Navigate().GoToUrl("http://10.75.205.122/esd/");
            driver.Navigate().GoToUrl(launchingURL);

            Thread.Sleep(3000);

            // Enter username
            String uname = cc.getDataFromFile("username");
            inputSim.Keyboard.TextEntry(uname);
            Thread.Sleep(1000);
            // press Tab key 
            inputSim.Keyboard.KeyPress(VirtualKeyCode.TAB);
            Thread.Sleep(1000);
            // Enter Password
            String passwd = cc.getDataFromFile("pass");
            inputSim.Keyboard.TextEntry(passwd);
            Thread.Sleep(2000);

            inputSim.Keyboard.KeyPress(VirtualKeyCode.RETURN);
            Thread.Sleep(15000);
            Assert.True(driver.Title.Contains("Flexera Software App Portal"));

            Console.WriteLine("Authentication Pop-up Login Completed through hooks");

            _container.RegisterInstanceAs<IWebDriver>(driver);

        }

        [AfterFeature]
        public void AfterFeature()
        {
            //TODO: implement logic that has to run after executing each scenario
            Console.WriteLine("Running after scenario...");
            var driver = _container.Resolve<IWebDriver>();

            Console.WriteLine("After Scenario driver value is: " + driver);

            if (driver != null)
            {
                driver.Quit();
            }
        }*/

        [BeforeScenario]
        // [BeforeScenario("RQ02_FA-30_tag1")]
        public void BeforeScenarioWithTag()
        {
            // Example of filtering hooks using tags. (in this case, this 'before scenario' hook will execute if the feature/scenario contains the tag '@tag1')
            // See https://docs.specflow.org/projects/specflow/en/latest/Bindings/Hooks.html?highlight=hooks#tag-scoping

            //TODO: implement logic that has to run before executing each scenario

            //TODO: implement logic that has to run before executing each scenario
            // IWebDriver driver = new Chrom
            connectAppPortal = connectAppPortal.DBConnect(servicesAppPortal);
            Console.WriteLine("Started before scenario...");
            if (cc.getDataFromFile("browser") == "chrome")
            {
                new WebDriverManager.DriverManager().SetUpDriver(new ChromeConfig());
                driver = new ChromeDriver();
            }
            else if(cc.getDataFromFile("browser") == "edge")
            {
                new WebDriverManager.DriverManager().SetUpDriver(new EdgeConfig());
                driver = new EdgeDriver();
            }
            else if (cc.getDataFromFile("browser") == "firefox")
            {
                new WebDriverManager.DriverManager().SetUpDriver(new FirefoxConfig());
                driver = new FirefoxDriver();
            }
            else
            {
                Console.WriteLine("Not a valid browser name");
            }

            driver.Manage().Window.Maximize();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
            driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(30);

            //_container.RegisterInstanceAs<IWebDriver>(driver);

            // Login Code

            Thread.Sleep(3000);

            // driver.Navigate().GoToUrl("http://10.75.204.205/esd");

            // Testing URL
            String launchingURL = cc.getDataFromFile("url");
            // driver.Navigate().GoToUrl("http://10.75.205.122/esd/");
            driver.Navigate().GoToUrl(launchingURL);

            Thread.Sleep(3000);

            // Enter username
            String uname = cc.getDataFromFile("username");
            inputSim.Keyboard.TextEntry(uname);
            Thread.Sleep(1000);
            // press Tab key 
            inputSim.Keyboard.KeyPress(VirtualKeyCode.TAB);
            Thread.Sleep(1000);
            // Enter Password
            String passwd = cc.getDataFromFile("pass");
            inputSim.Keyboard.TextEntry(passwd);
            Thread.Sleep(6000);

            
            inputSim.Keyboard.KeyPress(VirtualKeyCode.RETURN);
            Thread.Sleep(18000);
            Assert.True(driver.Title.Contains("Flexera Software App Portal"));

            Console.WriteLine("Authentication Pop-up Login Completed through hooks");

            _container.RegisterInstanceAs<IWebDriver>(driver);

        }

        /*[BeforeScenario(Order = 2)]
        public void FirstBeforeScenario()
        {
            // Example of ordering the execution of hooks
            // See https://docs.specflow.org/projects/specflow/en/latest/Bindings/Hooks.html?highlight=order#hook-execution-order

            //TODO: implement logic that has to run before executing each scenario
        }*/

        [AfterScenario]
        public void AfterScenario()
        {
            //TODO: implement logic that has to run after executing each scenario
            Console.WriteLine("Running after scenario...");
            var driver = _container.Resolve<IWebDriver>();

            Console.WriteLine("After Scenario driver value is: " + driver);
            connectAppPortal.Close();
            if (driver != null)
            {
                driver.Quit();
            }
        }
    }
}