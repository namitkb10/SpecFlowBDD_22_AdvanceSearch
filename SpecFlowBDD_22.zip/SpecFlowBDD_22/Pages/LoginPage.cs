﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpecFlowBDD_22.Pages
{
    internal class LoginPage
    {
    }
}
