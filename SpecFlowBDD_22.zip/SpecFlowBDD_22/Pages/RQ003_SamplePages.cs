﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using SpecFlowBDD_22.CommonClass;
using SpecFlowBDD_22.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpecFlowBDD_22.Pages
{
    public class RQ003_SamplePages
    {
        public IWebDriver rq03Driver;

        ClassCommon cc;

        RQ01_Pages rq01pages;
        WaitManager wm;

        [FindsBy(How = How.Id, Using = "ctl00_cph1_TitleSearch")]
        public IWebElement _chkBoxTitleSearch { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_BriefDescriptionSearch")]
        public IWebElement _chkBoxBriefDescriptionSearch { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_FullDescriptionSearch")]
        public IWebElement _chkBoxFullDescriptionSearch { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_KeywordSearch")]
        public IWebElement _chkBoxKeywordSearch { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_AdvancSearch")]
        public IWebElement _chkBoxEnableAdvancSearch { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_CatalogClassification")]
        public IWebElement _chkBoxCatalogClassification { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_DisplayCatalogClassification")]
        public IWebElement _chkBoxDisplayCatalogClassification { get; set; }

        [FindsBy(How = How.ClassName, Using = "rtbIn")]
        public IWebElement _saveButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[text()='Settings Saved.']")]
        public IWebElement _saveMessage { get; set; }


        [FindsBy(How = How.Id, Using = "searchCatalog")]
        public IWebElement _textBoxInputMainSearchCatalog { get; set; }

        [FindsBy(How = How.Id, Using = "searchButton")]
        public IWebElement _btnSearchButton { get; set; }

        [FindsBy(How = How.Id, Using = "resultsCountHeader")]
        public IWebElement _resultCount { get; set; }


        [FindsBy(How = How.Id, Using = "Catalog")]
        public IWebElement _browseCatalogTab { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[contains(text(),'There was no result for your search.')]")]
        public IWebElement _notFoundMessage { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@class='rtsTxt' and text()='Catalog Classification']")]
        public IWebElement _catalogClassificationTabButton { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_EnableCatalogClassification")]
        public IWebElement _chkBoxEnableCatalogClassification { get; set; }

        [FindsBy(How = How.Id, Using = "ddlResultsSort")]
        public IWebElement _sortByDropDownBox { get; set; }

        public RQ003_SamplePages(IWebDriver rDriver)
        {
            rq03Driver = rDriver;
            PageFactory.InitElements(rDriver, this);
        }


    }
}
