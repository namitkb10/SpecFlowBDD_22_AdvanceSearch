﻿using NUnit.Framework;
using OpenQA.Selenium;
using RazorEngine.Compilation.ImpromptuInterface;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpecFlowBDD_22.Pages
{
    public class RQ01_Pages
    {
        private readonly IWebDriver lDriver01;

        /*public RQ01_Pages(IWebDriver rDriver01)
        {
            lDriver01 = rDriver01;
            PageFactory.InitElements(rDriver01, this);
        }*/

        [FindsBy(How = How.Id, Using = "ctl00_cph1_AdvancSearch")]
        private IWebElement _weChkBoxEnableAdvanceSearchOptions;

        [FindsBy(How = How.XPath, Using = "//div[@class='userProfile header-right headerLine']/span[contains(text(),'Welcome')]")]
        // [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Welcome')]")]
        private IWebElement _welcomeTitle;
        //============================================================================


        //============================================================================
        private IWebDriver rq01_Driver { get; set; }



        //span[contains(text(),'Welcome')]



        public RQ01_Pages(IWebDriver rq01_Driver)
        {
            this.rq01_Driver = rq01_Driver;
            PageFactory.InitElements(rq01_Driver, this);
        }

        public void navigateToCatalogBehaviorTab()
        {
            rq01_Driver.FindElement(By.Id("Admin")).Click();
            if (!rq01_Driver.FindElement(By.Id("nodeSettings")).Displayed)
            {
                rq01_Driver.FindElement(By.Id("tnSiteConfiguration")).Click();
                Thread.Sleep(3000);
            }
            else
            {
                rq01_Driver.FindElement(By.Id("nodeSettings")).Click();
                Thread.Sleep(3000);
            }

            if(!rq01_Driver.FindElement(By.Id("RadPanelItem121")).Displayed)
            {
                rq01_Driver.FindElement(By.Id("nodeSettings")).Click();
                Thread.Sleep(1000);
                rq01_Driver.FindElement(By.Id("RadPanelItem121")).Click();
                Thread.Sleep(3000);
            }
            else
            {
                rq01_Driver.FindElement(By.Id("RadPanelItem121")).Click();
                Thread.Sleep(3000);
            }
            
            rq01_Driver.SwitchTo().Frame("RAD_SPLITTER_PANE_EXT_CONTENT_ctl00_cph1_topPane");

            //Thread.Sleep(1000);

            Console.WriteLine("Switched to Frame");
            rq01_Driver.FindElement(By.XPath("//span[contains(text(),'Catalog Behavior')]")).Click();

            Console.WriteLine("Default Page Chrome Driver: " + rq01_Driver);
            Console.WriteLine("Clicked on Catalog Behavior Button");
        }

        public void displayWelcome()
        {
            // Thread.Sleep(1000);
            if (_welcomeTitle.Displayed)
            {
                Console.WriteLine("is in app portal");
            }
            else
            {
                throw new Exception(string.Format("not in app portal page"));
            }
        }

        public void EnableAdvanceSearchOptionsDisplay()
        {
            IJavaScriptExecutor jse = (IJavaScriptExecutor)rq01_Driver;
            jse.ExecuteScript("window.scrollBy(0,450)", "");
            // je.ExecuteScript("arguments[0].scrollIntoView(true);", _weChkBoxEnableAdvanceSearchOptions);

            Thread.Sleep(1000);
            if (_weChkBoxEnableAdvanceSearchOptions.Displayed)
            {
                // Assert.True(_weChkBoxEnableAdvanceSearchOptions.Displayed);
                Console.WriteLine("Display Enable advance search options checkbox");
            }
            else
            {
                throw new Exception(string.Format("Enable advance search options checkbox not displaying"));
            }
        }

        public void EnableAdvanceSearchOptionsDefaultCheck()
        {
            if(!_weChkBoxEnableAdvanceSearchOptions.Selected)
            {
                _weChkBoxEnableAdvanceSearchOptions.Click();
                Console.WriteLine("Enable advance search options checkbox is Default Checked");
            }
            /*else
            {
                throw new Exception(string.Format("Enable advance search options checkbox is not Checked"));
            }*/
        }

        public void EnableAdvanceSearchOptionsClickAndUnCheck()
        {
            if (_weChkBoxEnableAdvanceSearchOptions.Selected)
            {
                _weChkBoxEnableAdvanceSearchOptions.Click();
               // Assert.True(!_weChkBoxEnableAdvanceSearchOptions.Selected);
                Console.WriteLine("Enable advance search options checkbox is unchecked");
            }
        }
        public void EnableAdvanceSearchOptionsUnCheck()
        {
            if (!_weChkBoxEnableAdvanceSearchOptions.Selected)
            {
                // Assert.True(!_weChkBoxEnableAdvanceSearchOptions.Selected);
                Console.WriteLine("Enable advance search options checkbox is unchecked");
            }
            else
            {
                throw new Exception(string.Format("Enable advance search options checkbox is Checked"));
            }
        }
    }
}
