﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using RazorEngine.Compilation.ImpromptuInterface;
using SeleniumExtras.PageObjects;
using SpecFlowBDD_22.CommonClass;
using SpecFlowBDD_22.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace SpecFlowBDD_22.Pages
{
    public class RQ03_Pages
    {
        public IWebDriver rq03Driver;

        ClassCommon cc;

        RQ01_Pages rq01pages;
        WaitManager wm;

        [FindsBy(How = How.Id, Using = "ctl00_cph1_TitleSearch")]
        public IWebElement _chkBoxTitleSearch { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_BriefDescriptionSearch")]
        public IWebElement _chkBoxBriefDescriptionSearch { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_FullDescriptionSearch")]
        public IWebElement _chkBoxFullDescriptionSearch { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_KeywordSearch")]
        public IWebElement _chkBoxKeywordSearch { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_AdvancSearch")]
        public IWebElement _chkBoxEnableAdvancSearch { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_CatalogClassification")]
        public IWebElement _chkBoxCatalogClassification { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_DisplayCatalogClassification")]
        public IWebElement _chkBoxDisplayCatalogClassification { get; set; }

        [FindsBy(How = How.ClassName, Using = "rtbIn")]
        public IWebElement _saveButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[text()='Settings Saved.']")]
        public IWebElement _saveMessage { get; set; }


        [FindsBy(How = How.Id, Using = "searchCatalog")]
        public IWebElement _textBoxInputMainSearchCatalog { get; set; }

        [FindsBy(How = How.Id, Using = "searchButton")]
        public IWebElement _btnSearchButton { get; set; }

        [FindsBy(How = How.Id, Using = "resultsCountHeader")]
        public IWebElement _resultCount { get; set; }


        [FindsBy(How = How.Id, Using = "Catalog")]
        public IWebElement _browseCatalogTab { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[contains(text(),'There was no result for your search.')]")]
        public IWebElement _notFoundMessage { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@class='rtsTxt' and text()='Catalog Classification']")]
        public IWebElement _catalogClassificationTabButton { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_EnableCatalogClassification")]
        public IWebElement _chkBoxEnableCatalogClassification { get; set; }

        [FindsBy(How = How.Id, Using = "ddlResultsSort")]
        public IWebElement _sortByDropDownBox { get; set; }

        [FindsBy(How = How.Id, Using = "resultsCategoryHeader")]
        public IWebElement _displaySearchResult { get; set; }

        



        public RQ03_Pages(IWebDriver rDriver)
        {
            rq03Driver = rDriver;
            PageFactory.InitElements(rDriver, this);
        }

        public void TitleSearchTermDataInTheSearchTextBox()
        {
            rq03Driver.SwitchTo().DefaultContent();
            _browseCatalogTab.Click();
            Thread.Sleep(3000);
            _textBoxInputMainSearchCatalog.SendKeys("t");
            Thread.Sleep(1000);
        }

        public void FullDescriptionSearchTermDataInTheSearchTextBox()
        {
            /*rq03Driver.SwitchTo().DefaultContent();
            _browseCatalogTab.Click();
            Thread.Sleep(3000);*/
            _textBoxInputMainSearchCatalog.SendKeys("full");
            Thread.Sleep(1000);
        }

        public void BriefDescriptionSearchTermDataInTheSearchTextBox()
        {
            /*rq03Driver.SwitchTo().DefaultContent();
            _browseCatalogTab.Click();
            Thread.Sleep(3000);*/
            _textBoxInputMainSearchCatalog.SendKeys("t");
            Thread.Sleep(1000);
        }

        public void ClickOnSearchIcon()
        {
            if (_btnSearchButton.Enabled)
            {
                _btnSearchButton.Click();
            }
            else
            {
                throw new Exception(string.Format("Search Button is not enabled"));
            }
        }

        public void VerifySearchResult()
        {
            var resultTxt = _resultCount.Text;
            String[] strArr = resultTxt.Split(" ");
            if (Int32.Parse(strArr[0]) > 0)
            {
                Console.WriteLine("Entered Text have" + Int32.Parse(strArr[0]) + " matched data");
            }
            else
            {
                throw new Exception(string.Format("Entered Text doesn't have matched data"));
            }
        }

        public void VerifySearchResultForBriefFullKeywordSearch()
        {

            // rq01pages = new RQ01_Pages(rq03Driver);
            // rq01pages.navigateToCatalogBehaviorTab();

            // cc = new ClassCommon();

            // cc.UncheckAllBasicSearchTerm(_chkBoxBriefDescriptionSearch, _chkBoxFullDescriptionSearch, _chkBoxKeywordSearch);
            // cc.CheckBasicSearchTerm(_chkBoxTitleSearch, _saveButton);

            // SaveAndNavigateToBrowseCatalogTab();

            BriefSearchTermDataInTheSearchTextBox(_textBoxInputMainSearchCatalog, _saveButton, "brief", "click");
            BriefSearchTermDataInTheSearchTextBox(_textBoxInputMainSearchCatalog, _saveButton, "full", "hitEnter");
            BriefSearchTermDataInTheSearchTextBox(_textBoxInputMainSearchCatalog, _saveButton, "keyword", "click");
        }

        public void SaveAndNavigateToBrowseCatalogTab()
        {
            if (_saveMessage.Text == "Settings Saved.")
            {
                Console.WriteLine("Saved message verified");
                rq03Driver.SwitchTo().DefaultContent();
                _browseCatalogTab.Click();
            }
            else
            {
                throw new Exception(string.Format("Saved message verified not verified"));
            }
        }

        public void BriefSearchTermDataInTheSearchTextBox(IWebElement textBoxInputMainSearchCatalog, IWebElement saveButton, string searchTerm, string text)
        {
             textBoxInputMainSearchCatalog.Clear();
            /*if (_notFoundMessage.Displayed)
            {
                _notFoundMessage.Clear();
            }*/
            if (text == "click" && searchTerm == "brief")
            {
                textBoxInputMainSearchCatalog.SendKeys("SonyMony");
                _btnSearchButton.Click();
            }
            /*else
            {
                textBoxInputMainSearchCatalog.SendKeys("SonyMony");
                textBoxInputMainSearchCatalog.SendKeys(Keys.Enter);
            }*/

            if (text == "hitEnter" && searchTerm == "full")
            {
                textBoxInputMainSearchCatalog.Clear();
                textBoxInputMainSearchCatalog.SendKeys("Enjoy clear calls");
                textBoxInputMainSearchCatalog.SendKeys(Keys.Enter);
            }

            if (text == "click" && searchTerm == "full")
            {
                textBoxInputMainSearchCatalog.Clear();
                textBoxInputMainSearchCatalog.SendKeys("Enjoy clear calls");
                textBoxInputMainSearchCatalog.SendKeys(Keys.Enter);
            }
            /*else
            {
                textBoxInputMainSearchCatalog.SendKeys("Enjoy clear calls");
                textBoxInputMainSearchCatalog.SendKeys(Keys.Enter);
            }*/

            if (text == "click" && searchTerm == "keyword")
            {
                textBoxInputMainSearchCatalog.Clear();
                textBoxInputMainSearchCatalog.SendKeys("Microphone");
                _btnSearchButton.Click();
            }
            /*else
            {
                textBoxInputMainSearchCatalog.SendKeys("Microphone");
                textBoxInputMainSearchCatalog.SendKeys(Keys.Enter);
            }*/

            if (_notFoundMessage.Text.Equals("There was no result for your search."))
            {
                Console.WriteLine("Entered data for" + searchTerm + "Search term not found");
            }
            else
            {
                throw new Exception(string.Format("Entered Text have matched data with" + searchTerm + "Search term"));
            }

            /*var resultTxt = _resultCount.Text;
            String[] strArr = resultTxt.Split(" ");
            if (Int32.Parse(strArr[0]) > 0)
            {
                Console.WriteLine("Entered Text have" + Int32.Parse(strArr[0]) + "matched data with " + searchTerm + "search term");
            }
            else
            {
                throw new Exception(string.Format("Entered Text doesn't have matched data with "  + searchTerm  + " search term"));
            }*/

        }

        /*public void BriefSearchTermNotValidDataInTheSearchTextBox()
        {
            _textBoxInputMainSearchCatalog.Clear();
            _textBoxInputMainSearchCatalog.SendKeys("Montana");
            _btnSearchButton.Click();

            if(_notFoundMessage.Text.Equals("There was no result for your search."))
            {
                Console.WriteLine("Entered data not found");
            }
            else
            {
                throw new Exception(string.Format("Entered Text doesn't have match data with brief description search"));
            }

                    //div[contains(text(),"There was no result for your search.")]
        }*/

        /*public void UncheckThreeBasicSearchTermParameterized(string briefDescription, string )
        {
            throw new NotImplementedException();
        }*/

        public void VerifyFullBriefKeywordSearchTermsIsUnchecked()
        {
            AssertionManager.UnChecked(_chkBoxBriefDescriptionSearch);
            AssertionManager.UnChecked(_chkBoxFullDescriptionSearch);
            AssertionManager.UnChecked(_chkBoxKeywordSearch);

            /*if (_chkBoxBriefDescriptionSearch.Selected)
            {
                _chkBoxBriefDescriptionSearch.Click();
            }

            if (_chkBoxFullDescriptionSearch.Selected)
            {
                _chkBoxFullDescriptionSearch.Click();
            }

            if (_chkBoxKeywordSearch.Selected)
            {
                _chkBoxKeywordSearch.Click();
            }


            _saveButton.Click();
            Thread.Sleep(3000);

            bool flag = (!_chkBoxBriefDescriptionSearch.Selected && !_chkBoxFullDescriptionSearch.Selected && !_chkBoxKeywordSearch.Selected);
            Thread.Sleep(1000);
            if (flag)
            {
                //Assert.True(flag);
                Console.WriteLine("Brief, Full & Keyword search term checkbox is not checked");
            }
            else
            {
                throw new Exception(string.Format("Brief Description, Full Description & Keyword search term, either of them is checked"));
            }*/

            //SaveAndNavigateToBrowseCatalogTab();
        }
        //===========================Below Added for Scenario03 method mostly============================================================

        public void CheckTitleSearchTerm()
        {
            if (!_chkBoxTitleSearch.Selected)
            {
                _chkBoxTitleSearch.Click();
                Console.Write("Title Search term CheckBox is Checked");
            }
            /*else
            {
                throw new Exception(string.Format("Title Search term CheckBox is still Unchecked"));
            }*/
        }

        public void UncheckTitleSearchTerm()
        {
            if (_chkBoxTitleSearch.Selected)
            {
                _chkBoxTitleSearch.Click();
                Console.Write("Title Search term CheckBox is unchecked");
            }
            /*else
            {
                throw new Exception(string.Format("Title Search term CheckBox is still checked"));
            }*/
        }

        public void CheckBriefDescriptionSearchTerm()
        {
            if (!_chkBoxBriefDescriptionSearch.Selected)
            {
                _chkBoxBriefDescriptionSearch.Click();
                Console.Write("Brief Description term CheckBox is checked");
            }
        }

        public void UncheckBriefDescriptionSearchTerm()
        {
            if (_chkBoxBriefDescriptionSearch.Selected)
            {
                _chkBoxBriefDescriptionSearch.Click();
                Console.Write("Brief Description Search term CheckBox is unchecked");
            }
            /*else
            {
                throw new Exception(string.Format("Brief Description Search term CheckBox is still checked"));
            }*/
        }

        public void CheckFullDescriptionSearchTerm()
        {
            if (!_chkBoxFullDescriptionSearch.Selected)
            {
                _chkBoxFullDescriptionSearch.Click();
                Console.Write("Full Description Search term CheckBox is Checked");
            }
        }

        public void UncheckFullDescriptionSearchTerm()
        {
            if (_chkBoxFullDescriptionSearch.Selected)
            {
                _chkBoxFullDescriptionSearch.Click();
                Console.Write("Full Description Search term CheckBox is unchecked");
            }
            /*else
            {
                throw new Exception(string.Format("Full Description Search term Click CheckBox is still checked"));
            }*/
        }

        public void CheckKeywordSearchTerm()
        {
            if (!_chkBoxKeywordSearch.Selected)
            {
                _chkBoxKeywordSearch.Click();
                Console.Write("Keyword Search term CheckBox is checked");
            }
        }

        public void UncheckKeywordSearchTerm()
        {
            if (_chkBoxKeywordSearch.Selected)
            {
                _chkBoxKeywordSearch.Click();
                Console.Write("Keyword Search term CheckBox is unchecked");
            }
            /*else
            {
                throw new Exception(string.Format("Keyword Search term CheckBox is still checked"));
            }*/
        }
        public void EnableAdvanceSearchOptionsChkBoxCheckedByDefault()
        {
            if (!_chkBoxEnableAdvancSearch.Selected)
            {
                _chkBoxEnableAdvancSearch.Click();
                Console.Write("Enable Advance Search Options Check Box Checked By Default");
            }
            /*else
            {
                throw new Exception(string.Format("Keyword Search term CheckBox is still checked"));
            }*/
        }

        public void SaveAndVerify()
        {
            _saveButton.Click();
            Thread.Sleep(1000);
            // wm.ScrollToWebElement(By.ClassName("rtbIn"));
            if (_saveMessage.Text == "Settings Saved.")
            {
                Console.WriteLine("Saved message verified");
            }
            /*else
            {
                throw new Exception(string.Format("Saved message verified not verified"));
            }*/
        }

        public void NavigateToBrowseCatalogTab()
        {
             rq03Driver.SwitchTo().DefaultContent();
            _browseCatalogTab.Click();
        }

        public void SearchTermDataInTheSearchTextBox(String strText)
        {
            /*rq03Driver.SwitchTo().DefaultContent();
            _browseCatalogTab.Click();
            Thread.Sleep(3000);*/
            _textBoxInputMainSearchCatalog.Clear();
            _textBoxInputMainSearchCatalog.SendKeys(strText);
            Thread.Sleep(1000);
        }

        public void ClickOnSearchIconButton()
        {
            if(_btnSearchButton.Enabled)
            {
                _btnSearchButton.Click();
                Console.WriteLine("Search Button Clicked");
            }
            else
            {
                throw new Exception(string.Format("Search button icon is not enabled"));
            }
        }

        public void ClickOnHitEnterButtonFromKeyboard()
        {
            if (_textBoxInputMainSearchCatalog.Enabled)
            {
                _textBoxInputMainSearchCatalog.SendKeys(Keys.Enter);
                Console.WriteLine("Hit Enter Working");
            }
            else
            {
                throw new Exception(string.Format("Hit Enter Search not Working"));
            }
        }

        public void verifyUncheckInvalidSearchTermData(string searchTerm)
        {
            if (_notFoundMessage.Text.Equals("There was no result for your search."))
            {
                Console.WriteLine("Entered data for" + searchTerm + "Search term not found");
            }
            else
            {
                throw new Exception(string.Format("Entered Text have matched data with" + searchTerm + "Search term"));
            }
        }

        // =============================Scenario10==============================

        

        public void EnableSearchByCatalogClassificationChkBoxShouldDisplayAsChecked()
        {
            if (_chkBoxCatalogClassification.Selected)
            {
                Console.WriteLine("Enable search by catalog classification Checkbox is cheked");
            }
            else
            {
                Console.WriteLine("Enable search by catalog classification Checkbox is not cheked");
            }
        }

        public void NavigateToTheCatalogClassificationPageTab()
        {
            if(_catalogClassificationTabButton.Enabled)
            {
                _catalogClassificationTabButton.Click();
            }
        }

        public void CheckEnableCatalogClassificationChkBox()
        {
            if(!_chkBoxEnableCatalogClassification.Selected)
            {
                _chkBoxEnableCatalogClassification.Click();
            }
        }

        public void UncheckEnableCatalogClassificationChkBox()
        {
            Thread.Sleep(1000);
            if (_chkBoxEnableCatalogClassification.Selected)
            {
                _chkBoxEnableCatalogClassification.Click();
                Console.WriteLine("Enable Catalog Classification Check Box Unchecked");
            }
        }

        public void DisplayEnableCatalogClassificationChkBoxAsChecked()
        {
            if (_chkBoxEnableCatalogClassification.Selected)
            {
                Console.WriteLine("Enable Catalog Classification Check Box is Checked");
                
            }
            else
            {
                throw new Exception(string.Format("Enable Catalog Classification Check Box is not Checked"));
            }
        }

        public void TitleBriefDescriptionAndKeywordSearchTermsCheckBoxesAreUnchecked()
        {
            if (_chkBoxBriefDescriptionSearch.Selected)
            {
                _chkBoxBriefDescriptionSearch.Click();
            }

            if (_chkBoxTitleSearch.Selected)
            {
                _chkBoxTitleSearch.Click();
            }

            if (_chkBoxKeywordSearch.Selected)
            {
                _chkBoxKeywordSearch.Click();
            }
        }

        public void VerifyParameterOptionIsSelectedInTheSortDropdownBox(string selectedValueInDropDownBox)
        {
            SelectElement status = new SelectElement(_sortByDropDownBox);
            IWebElement selected = status.SelectedOption;
            Console.Write("Selected value in Drop Down Box is" + selected.Text);
            if (selected.Text == selectedValueInDropDownBox)
            {
                Console.WriteLine("Drop Down Selected Value Verified");
            }
            else
            {
                throw new Exception(string.Format("Drop Down Selected Value not Verified"));
            }
        }

        public void VerifyParameterOptionIsNotSelectedInTheSortDropdownBox(string selectedValueInDropDownBox)
        {
            SelectElement status = new SelectElement(_sortByDropDownBox);
            IWebElement selected = status.SelectedOption;
            Console.Write("Selected value in Drop Down Box is" + selected.Text);
            if (selected.Text != selectedValueInDropDownBox)
            {
                Console.WriteLine("Drop Down Selected Value Verified");
            }
            else
            {
                throw new Exception(string.Format("Drop Down Selected Value not Verified"));
            }
        }

        public void AllTheSearchResultsShouldBeAutomaticallySortedByTheAlphabeticallyAndNotByClassifications()
        {
            var alphabetical = true;
            List<string> actualLinkList;
            List<string> newSortedList;

                IList<IWebElement> listWebElementText = rq03Driver.FindElements(By.XPath("//div[@class='showcaseCardTitle']"));
                actualLinkList = new List<string>();
                newSortedList = new List<string>();
                
                foreach (var item in listWebElementText)
                {
                    actualLinkList.Add(item.Text);
                    newSortedList.Add(item.Text);
                }

                newSortedList.Sort();

                if (actualLinkList.Count > 1)
                {
                    alphabetical = true;
                    for (int j = 0; j < listWebElementText.Count - 1; j++)
                    {
                        if (actualLinkList[j] != newSortedList[j])
                        {
                            alphabetical = false;
                            break;
                        }
                    }
                }
                if (alphabetical == false)
                {
                    throw new Exception(string.Format("Displayed data is not in sorted order"));
                }
        }
    }
}
