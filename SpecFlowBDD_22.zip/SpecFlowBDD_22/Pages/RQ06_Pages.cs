﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpecFlowBDD_22.Pages
{
    public class RQ06_Pages
    {
        RQ05_Pages rq05pages;
        RQ01_Pages rQ01_Pages;
        public IWebDriver rq06Driver;
        string catalogClassificationType;
        public static string selectedTitleText;
        string parentWindowHandle;

        [FindsBy(How = How.XPath, Using = "//a[@class='rtbWrap']")]
        public IWebElement _btnImpersonationNew { get; set; }

        [FindsBy(How = How.XPath, Using = "//em[text()='New Impersonation']")]
        public IWebElement _pageImpersonationNew { get; set; }
        


        //================================================================================
        [FindsBy(How = How.Id, Using = "ctl00_cph1_txtImpersonatedAccount")]
        public IWebElement _txtBoxImpersonateUser { get; set; }

        [FindsBy(How = How.Name, Using = "ctl00$cph1$SecurityGroupPicker1$ddlDomain")]
        public IWebElement _ddlSelectAccountToImpersonate { get; set; }


        [FindsBy(How = How.Id, Using = "ctl00_cph1_SecurityGroupPicker1_txtSearchValue")]
        public IWebElement _txtBoxCurrentUserImpersonate { get; set; }


        [FindsBy(How = How.Id, Using = "ctl00_cph1_SecurityGroupPicker1_btnSearch")]
        public IWebElement _btnSearchImpersonation { get; set; }


        [FindsBy(How = How.Id, Using = "ctl00_cph1_SecurityGroupPicker1_lbSearchResults_i0")]
        public IWebElement _txtSearchResult1 { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_btnAdd_input")]
        public IWebElement _btnAddSelectedAccount { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_rlbImpersonate_i0")]
        public IWebElement _txtSearchSelectUser { get; set; }


        [FindsBy(How = How.XPath, Using = "//span[@class='rtbText' and text()='Save']")]
        public IWebElement _btnImpersonationSave { get; set; }


        [FindsBy(How = How.Id, Using = "//a[@class='rwCloseButton']")]
        public IWebElement _crossCloseButton { get; set; }


        //it consist of iframe name: Impersonate

        //================================================================================

        public RQ06_Pages(IWebDriver rDriver)
        {
            rq06Driver = rDriver;
            PageFactory.InitElements(rDriver, this);
        }

        public void navigateToImpersonationPage()
        {

            //rq06Driver.FindElement(By.Id("Admin")).Click();
            rq06Driver.SwitchTo().DefaultContent();
            if (!rq06Driver.FindElement(By.XPath("//a[@id='tnActiveDirectory']//span[text()='Active Directory']")).Displayed)
            {
                rq06Driver.FindElement(By.Id("tnSiteConfiguration")).Click();
                Thread.Sleep(3000);
            }
            else
            {
                rq06Driver.FindElement(By.XPath("//a[@id='tnActiveDirectory']//span[text()='Active Directory']")).Click();
                Thread.Sleep(3000);
            }

            rq06Driver.FindElement(By.XPath("//span[@class='rpText' and text()='User Impersonation']")).Click();

            /*if (!rq01_Driver.FindElement(By.Id("RadPanelItem121")).Displayed)
            {
                rq01_Driver.FindElement(By.Id("nodeSettings")).Click();
                Thread.Sleep(1000);
                rq01_Driver.FindElement(By.Id("RadPanelItem121")).Click();
                Thread.Sleep(3000);
            }
            else
            {
                rq01_Driver.FindElement(By.Id("RadPanelItem121")).Click();
                Thread.Sleep(3000);
            }

            rq01_Driver.SwitchTo().Frame("RAD_SPLITTER_PANE_EXT_CONTENT_ctl00_cph1_topPane");

            //Thread.Sleep(1000);

            Console.WriteLine("Switched to Frame");
            rq01_Driver.FindElement(By.XPath("//span[contains(text(),'Catalog Behavior')]")).Click();

            Console.WriteLine("Default Page Chrome Driver: " + rq01_Driver);
            Console.WriteLine("Clicked on Catalog Behavior Button");*/
        }
    }
}
