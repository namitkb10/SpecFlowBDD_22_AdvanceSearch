05_June_2023
1) Reading data from TestData >> testdatafile.txt
2) Automation test script working in chrome & edge browser as expected (reading data from testdatafile)
3) 