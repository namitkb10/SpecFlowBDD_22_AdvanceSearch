﻿using OpenQA.Selenium;
using SpecFlowBDD_22.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpecFlowBDD_22.StepDefinitions
{
    [Binding]
    public class RQ003_SampleStepDefinition
    {

        public IWebDriver rq003_Sample_Driver;
        RQ02_Pages rq02pages;

        public RQ003_SampleStepDefinition(IWebDriver rDriver)
        {
            this.rq003_Sample_Driver = rDriver;
            //PageFactory.
        }

        
        RQ003_SamplePages rq003Samplepages;

        [When(@"click on Browse Catalog, enter the search term and click on search button")]
        public void WhenClickOnBrowseCatalogEnterTheSearchTermAndClickOnSearchButton()
        {
            rq003Samplepages._browseCatalogTab.Click();
            rq003Samplepages._textBoxInputMainSearchCatalog.SendKeys("e");
            rq003Samplepages._btnSearchButton.Click();

        }

        [Then(@"Veify tha data in \(catalog classification order\) and sorted \(sorted alphabetically\)")]
        public void ThenVeifyThaDataInCatalogClassificationOrderAndSortedSortedAlphabetically()
        {
            
        }


    }
}
