﻿using NUnit.Framework;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using SpecFlowBDD_22.HooksManager;
using SpecFlowBDD_22.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace SpecFlowBDD_22.StepDefinitions
{
    [Binding]
    public sealed class RQ01_StepDefinitions
    {
        private IWebDriver rq01_Driver;

        
        public RQ01_StepDefinitions(IWebDriver rDriver)
        {
            this.rq01_Driver = rDriver;
            //PageFactory.
        }

        RQ01_Pages rq01pages;

        [Given(@"admin user is logged into the app portal")]
        public void GivenAdminUserIsLoggedIntoTheAppPortal()
        {
            Console.WriteLine("Login is completed");
            Console.WriteLine("Step-1");

            rq01pages = new RQ01_Pages(rq01_Driver);
            rq01pages.displayWelcome();
        }

        [When(@"user navigate to the Catalog Behavior Page\(Admin >> Site Management >> Settings >> Web Site >> Catalog Behavior Page\)")]
        public void WhenUserNavigateToTheCatalogBehaviorPageAdminSiteManagementSettingsWebSiteCatalogBehaviorPage()
        {
            Console.WriteLine("Step-2");

            rq01pages = new RQ01_Pages(rq01_Driver);
            rq01pages.navigateToCatalogBehaviorTab();
        }

        [When(@"user navigated to Catalog Behavior Page")]
        public void WhenUserNavigatedToCatalogBehaviorPage()
        {
            Console.WriteLine("User navigated to Catalog Behavior Page");
        }


        [Then(@"the page should display Enable advance search options checkbox")]
        public void ThenThePageShouldDisplayEnableAdvanceSearchOptionsCheckbox()
        {
            Console.WriteLine("Step-3");
            rq01pages = new RQ01_Pages(rq01_Driver);
            rq01pages.EnableAdvanceSearchOptionsDisplay();
        }

        [Then(@"“Enable advance search options” check box should be checked\(by default\)")]
        public void ThenEnableAdvanceSearchOptionsCheckBoxShouldBeCheckedByDefault()
        {
            Console.WriteLine("Step-4");
            rq01pages.EnableAdvanceSearchOptionsDefaultCheck();
        }

        [When(@"user uncheck the “Enable advance search options” checkbox")]
        public void WhenUserUncheckTheEnableAdvanceSearchOptionsCheckbox()
        {
            Console.WriteLine("Step-5");
            rq01pages.EnableAdvanceSearchOptionsClickAndUnCheck();
        }

        [Then(@"“Enable advance search options” checkbox should be displayed as unchecked")]
        public void ThenEnableAdvanceSearchOptionsCheckboxShouldBeDisplayedAsUnchecked()
        {
            Console.WriteLine("Step-6");
            // throw new PendingStepException();
            rq01pages.EnableAdvanceSearchOptionsUnCheck();
        }
    }
}
