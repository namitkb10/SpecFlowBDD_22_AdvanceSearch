﻿using OpenQA.Selenium;
using SpecFlowBDD_22.Framework;
using SpecFlowBDD_22.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpecFlowBDD_22.StepDefinitions
{
    [Binding]
    public sealed class RQ02_StepDefinitions
    {
        private IWebDriver rq02_Driver;
        RQ02_Pages rq02pages;
        public RQ02_StepDefinitions(IWebDriver rDriver)
        {
            this.rq02_Driver = rDriver;
            //PageFactory.
        }

        //=======================================================
        // @RQ02_FA-30_tag1 - (3rd Steps)
        [Then(@"the Admin should be able to view the different search terms \(Title, Brief Description, Full Description, Keyword\)")]
        public void ThenTheAdminShouldBeAbleToViewTheDifferentSearchTermsTitleBriefDescriptionFullDescriptionKeyword()
        {
            rq02pages = new RQ02_Pages(rq02_Driver);
            rq02pages.VerifyAllBasicSearchTermsToDisplay();
        }

         // 4th Steps
        [Then(@"the Admin should be able to view the different Enable advance search options\(Enable search by catalog classification,Enable search result display based on catalog classification,Enable fuzzy logic search,Enable search history based on user profile\) check boxes")]
        public void ThenTheAdminShouldBeAbleToViewTheDifferentEnableAdvanceSearchOptionsEnableSearchByCatalogClassificationEnableSearchResultDisplayBasedOnCatalogClassificationEnableFuzzyLogicSearchEnableSearchHistoryBasedOnUserProfileCheckBoxes()
        {
            // throw new PendingStepException();
            rq02pages = new RQ02_Pages(rq02_Driver);
            rq02pages.VerifyAllAdvanceSearchTermsToDisplay();
        }

        //=======================================================
        // @RQ02_FA-30_tag2(1st Step)
        [Then(@"Admin user should be able to view the Title search term with the check box")]
        public void ThenAdminUserShouldBeAbleToViewTheTitleSearchTermWithTheCheckBox()
        {
            // throw new PendingStepException();
            rq02pages = new RQ02_Pages(rq02_Driver);
            rq02pages.VerifyTitleSearchTermsToDisplay();
        }

        [When(@"user ensure the ""([^""]*)"" search term checkbox\(is checked\)")]
        public void WhenUserEnsureTheSearchTermCheckboxIsChecked(string searchTerm)
        {
            rq02pages = new RQ02_Pages(rq02_Driver);
            if (searchTerm == "Title")
            {
                if(!rq02pages._chkBoxTitleSearch.Selected)
                {
                    rq02pages._chkBoxTitleSearch.Click();
                }
            }
            else if (searchTerm == "Full description")
            {
                if (!rq02pages._chkBoxFullDescriptionSearch.Selected)
                {
                    rq02pages._chkBoxFullDescriptionSearch.Click();
                }
            }

            else if (searchTerm == "Brief description")
            {
                if (!rq02pages._chkBoxBriefDescriptionSearch.Selected)
                {
                    rq02pages._chkBoxBriefDescriptionSearch.Click();
                }
            }

            else if (searchTerm == "Keyword")
            {
                if (!rq02pages._chkBoxKeywordSearch.Selected)
                {
                    rq02pages._chkBoxKeywordSearch.Click();
                }
            }
        }

        [Then(@"""([^""]*)"" search term checkbox should be checked")]
        public void ThenSearchTermCheckboxShouldBeChecked(string searchTerm)
        {
            rq02pages = new RQ02_Pages(rq02_Driver);
            if (searchTerm == "Title")
            {
                AssertionManager.Checked(rq02pages._chkBoxTitleSearch);
            }
            else if (searchTerm == "Full description")
            {
                AssertionManager.Checked(rq02pages._chkBoxFullDescriptionSearch);
            }

            else if (searchTerm == "Brief description")
            {
                AssertionManager.Checked(rq02pages._chkBoxBriefDescriptionSearch);
            }

            else if (searchTerm == "Keyword")
            {
                AssertionManager.Checked(rq02pages._chkBoxKeywordSearch);
            }
        }



        /*[Then(@"Title search term check box should be enabled and checked\(by default\)")]
        public void ThenTitleSearchTermCheckBoxShouldBeEnabledAndCheckedByDefault()
        {
            rq02pages = new RQ02_Pages(rq02_Driver);
            rq02pages.VerifyTitleSearchTermsEnabledAndCheckedByDefault();
        }*/

        // Repeat-d-----------------------
        /*[When(@"Admin user click\(uncheck\) on the Title search term check box")]
        public void WhenAdminUserClickUncheckOnTheTitleSearchTermCheckBox()
        {
            // throw new PendingStepException();
            rq02pages = new RQ02_Pages(rq02_Driver);
            rq02pages.VerifyTitleSearchTermsClickAndUncheck();
        }*/

        [When(@"user Uncheck the ""([^""]*)"" search term check box")]
        public void WhenUserUncheckTheSearchTermCheckBox(string basicSearchTermList)
        {
            //rq02pages = new RQ02_Pages(rq02_Driver);
            rq02pages = new RQ02_Pages(rq02_Driver);
            string[] searchTerm = basicSearchTermList.Split(',');
            foreach (var term in searchTerm)
            {
                switch (term.Trim())
                {
                    case "Full description":
                        if (rq02pages._chkBoxFullDescriptionSearch.Selected)
                        {
                            rq02pages._chkBoxFullDescriptionSearch.Click();
                        }
                        break;
                    case "Brief description":
                        if (rq02pages._chkBoxBriefDescriptionSearch.Selected)
                        {
                            rq02pages._chkBoxBriefDescriptionSearch.Click();
                        }
                        break;
                    case "Keyword":
                        if (rq02pages._chkBoxKeywordSearch.Selected)
                        {
                            rq02pages._chkBoxKeywordSearch.Click();
                        }
                        break;
                    case "Title":
                        if (rq02pages._chkBoxTitleSearch.Selected)
                        {
                            rq02pages._chkBoxTitleSearch.Click();
                        }
                        break;
                }
            }
        }

        [When(@"user Check the ""([^""]*)"" search term check box")]
        public void WhenUserCheckTheSearchTermCheckBox(string basicSearchTermList)
        {
            //rq02pages = new RQ02_Pages(rq02_Driver);
            rq02pages = new RQ02_Pages(rq02_Driver);
            string[] searchTerm = basicSearchTermList.Split(',');
            foreach (var term in searchTerm)
            {
                switch (term)
                {
                    case "Full description":
                        if (!rq02pages._chkBoxFullDescriptionSearch.Selected)
                        {
                            rq02pages._chkBoxFullDescriptionSearch.Click();
                        }
                        break;
                    case "Brief description":
                        if (!rq02pages._chkBoxBriefDescriptionSearch.Selected)
                        {
                            rq02pages._chkBoxBriefDescriptionSearch.Click();
                        }
                        break;
                    case "Keyword":
                        if (!rq02pages._chkBoxKeywordSearch.Selected)
                        {
                            rq02pages._chkBoxKeywordSearch.Click();
                        }
                        break;
                    case "Title":
                        if (!rq02pages._chkBoxTitleSearch.Selected)
                        {
                            rq02pages._chkBoxTitleSearch.Click();
                        }
                        break;
                }
            }
        }


        [Then(@"The Title search term check box should display as unchecked")]
        public void ThenTheTitleSearchTermCheckBoxShouldDisplayAsUnchecked()
        {
            // throw new PendingStepException();
            rq02pages = new RQ02_Pages(rq02_Driver);
            rq02pages.VerifyTitleSearchTermsIsUncheck();
        }
        // Repeat-u-----------------------
        [When(@"Admin user click\(check\) on the Title search term check box")]
        public void WhenAdminUserClickCheckOnTheTitleSearchTermCheckBox()
        {
            rq02pages = new RQ02_Pages(rq02_Driver);
            rq02pages.VerifyTitleSearchTermsClickAndCheck();
        }

        [Then(@"The Title search term check box should display as checked")]
        public void ThenTheTitleSearchTermCheckBoxShouldDisplayAsChecked()
        {
            rq02pages = new RQ02_Pages(rq02_Driver);
            rq02pages.VerifyTitleSearchTermsIsChecked();
        }
        // @RQ02_FA-30_tag3

        [Then(@"Admin user should be able to view the \(Full description\),\(Brief description\) and \(Keyword\) search terms with the check box as enable")]
        public void ThenAdminUserShouldBeAbleToViewTheFullDescriptionBriefDescriptionAndKeywordSearchTermsWithTheCheckBoxAsEnable()
        {
            rq02pages = new RQ02_Pages(rq02_Driver);
            rq02pages.VerifyBasicSearchTermsToDisplayAndEnable();
        }

        /*[Then(@"Full description,Brief description and Keyword search terms check boxs should be displayed as unchecked")]
        public void ThenFullDescriptionBriefDescriptionAndKeywordSearchTermsCheckBoxsShouldBeDisplayedAsUnchecked()
        {
            rq02pages = new RQ02_Pages(rq02_Driver);
            AssertionManager.UnChecked(rq02pages._chkBoxBriefDescriptionSearch);
            AssertionManager.UnChecked(rq02pages._chkBoxFullDescriptionSearch);
            AssertionManager.UnChecked(rq02pages._chkBoxKeywordSearch);
        }*/

        [Then(@"""([^""]*)"" search terms check boxs should be displayed as unchecked")]
        public void ThenSearchTermsCheckBoxsShouldBeDisplayedAsUnchecked(string basicSearchTermList)
        {
            rq02pages = new RQ02_Pages(rq02_Driver);
            string[] searchTerm = basicSearchTermList.Split(',');
            foreach (var term in searchTerm)
            {
                switch(term)
                {
                    case "Full description":
                        AssertionManager.UnChecked(rq02pages._chkBoxFullDescriptionSearch);
                        break;
                    case "Brief description":
                        AssertionManager.UnChecked(rq02pages._chkBoxBriefDescriptionSearch);
                        break;
                    case "Keyword":
                        AssertionManager.UnChecked(rq02pages._chkBoxKeywordSearch);
                        break;
                    case "Title":
                        AssertionManager.UnChecked(rq02pages._chkBoxTitleSearch);
                        break;
                }
            }
        }

        [Then(@"""([^""]*)"" search terms check boxs should be displayed as Checked")]
        public void ThenSearchTermsCheckBoxsShouldBeDisplayedAsChecked(string basicSearchTermList)
        {
            rq02pages = new RQ02_Pages(rq02_Driver);
            string[] searchTerm = basicSearchTermList.Split(',');
            foreach (var term in searchTerm)
            {
                switch (term)
                {
                    case "Full description":
                        AssertionManager.Checked(rq02pages._chkBoxFullDescriptionSearch);
                        break;
                    case "Brief description":
                        AssertionManager.Checked(rq02pages._chkBoxBriefDescriptionSearch);
                        break;
                    case "Keyword":
                        AssertionManager.Checked(rq02pages._chkBoxKeywordSearch);
                        break;
                    case "Title":
                        AssertionManager.Checked(rq02pages._chkBoxTitleSearch);
                        break;
                }
            }
        }


        /*[Then(@"""([^""]*)"",""([^""]*)"" and ""([^""]*)"" search terms check boxs should be displayed as unchecked")]
        public void ThenAndSearchTermsCheckBoxsShouldBeDisplayedAsUnchecked(string searchTerm1, string searchTerm2, string searchTerm3)
        {
            if()
        }*/

        [When(@"Admin user click\(check\) on the \(Full description\),\(Brief description\) and \(Keyword\) search terms check boxs")]
        public void WhenAdminUserClickCheckOnTheFullDescriptionBriefDescriptionAndKeywordSearchTermsCheckBoxs()
        {
            rq02pages = new RQ02_Pages(rq02_Driver);
            rq02pages.VerifyBasicSearchTermsIsClickedAndChecked();
        }

        [Then(@"\(Full description\),\(Brief description\) and \(Keyword\) search terms check boxs should be displayed as checked")]
        public void ThenFullDescriptionBriefDescriptionAndKeywordSearchTermsCheckBoxsShouldBeDisplayedAsChecked()
        {
            rq02pages = new RQ02_Pages(rq02_Driver);
            rq02pages.VerifyBasicSearchTermsIsChecked();
        }

        [When(@"Admin user click\(uncheck\) on the \(Full description\),\(Brief description\) and \(Keyword\) search terms check boxs")]
        public void WhenAdminUserClickUncheckOnTheFullDescriptionBriefDescriptionAndKeywordSearchTermsCheckBoxs()
        {
            rq02pages = new RQ02_Pages(rq02_Driver);
            rq02pages.VerifyBasicSearchTermsIsClickedAndUnchecked();
        }

        // @RQ02_FA-30_tag3 - End

        // @RQ02_FA-30_tag4 - Begin

        [Then(@"Title,Full description,Brief description and Keyword search terms check boxs should be enable for the admin user")]
        public void ThenTitleFullDescriptionBriefDescriptionAndKeywordSearchTermsCheckBoxsShouldBeEnableForTheAdminUser()
        {
            rq02pages = new RQ02_Pages(rq02_Driver);
            rq02pages.AllSearchTermOptionsareEnabled();
        }

        [Then(@"the page should display “Enable advance search options” checkbox")]
        public void ThenThePageShouldDisplayEnableAdvanceSearchOptionsCheckbox()
        {
            rq02pages = new RQ02_Pages(rq02_Driver);
            rq02pages.VerifyEnableAdvanceSearchOptionsIsDisplayedAndEnabled();
        }
        
        [Then(@"'([^']*)','([^']*)','([^']*)' and '([^']*)' search terms check boxs should be enable for the admin user")]
        public void ThenAndSearchTermsCheckBoxsShouldBeEnableForTheAdminUser(string title, string p1, string p2, string keyword)
        {
            rq02pages = new RQ02_Pages(rq02_Driver);
            rq02pages.VerifyOnByDefaultCheckOnEnableAdvanceSearchOptionsBasicSearchTermIsEnabled();
        }

        [When(@"admin user click on\(uncheck\) “Enable advance search options” check box")]
        public void WhenAdminUserClickOnUncheckEnableAdvanceSearchOptionsCheckBox()
        {
            rq02pages = new RQ02_Pages(rq02_Driver);
            //rq02pages.VerifyOnClickAndUncheckOfEnableAdvanceSearchOptionsBasicSearchTermIsEnabled();
            rq02pages.VerifyOnUncheckOfEnableAdvanceSearchOptionsOtherCheckBoxShouldUncheckedAndDisabled();
        }

        [Then(@"""([^""]*)"" check boxs should be enable for the admin user")]
        public void ThenCheckBoxsShouldBeEnableForTheAdminUser(string p0)
        {
            rq02pages = new RQ02_Pages(rq02_Driver);
            // rq02pages.VerifyOnByDefaultCheckOnEnableAdvanceSearchOptionsBasicSearchTermIsEnabled();
            rq02pages.VerifyOnCheckOfEnableAdvanceSearchOptionsOtherCheckBoxShouldDisplayAndEnable();
        }

        [Then(@"all the ""([^""]*)"" terms should be unchecked\(by default\)")]
        public void ThenAllTheTermsShouldBeUncheckedByDefault(string p0)
        {
            rq02pages = new RQ02_Pages(rq02_Driver);
            rq02pages.VerifyOnCheckOfEnableAdvanceSearchOptionsOtherCheckBoxShouldByDefaultUnchecked();
        }

        [Then(@"""([^""]*)"" check boxs should be disabled and unchecked for the admin user")]
        public void ThenCheckBoxsShouldBeDisabledAndUncheckedForTheAdminUser(string p0)
        {
            rq02pages = new RQ02_Pages(rq02_Driver);
            // rq02pages.VerifyOnClickAndUncheckOfEnableAdvanceSearchOptionsBasicSearchTermIsEnabled();
            rq02pages.VerifyOnUncheckOfEnableAdvanceSearchOptionsOtherCheckBoxShouldUncheckedAndDisabled();
        }

        // @RQ02_FA-30_tag5
        //3rd
        [Then(@"Enable search by catalog classification,Enable fuzzy logic search,Enable search history based on user profile check boxs should be enable for the admin user")]
        public void ThenEnableSearchByCatalogClassificationEnableFuzzyLogicSearchEnableSearchHistoryBasedOnUserProfileCheckBoxsShouldBeEnableForTheAdminUser()
        {
            rq02pages = new RQ02_Pages(rq02_Driver);
            rq02pages.AllEnableAdvanceSearchOptionsareEnabled();
        }
        //4th
        [Then(@"all the Enabe advance search options terms should be unchecked\(by default\)")]
        public void ThenAllTheEnabeAdvanceSearchOptionsTermsShouldBeUncheckedByDefault()
        {
            rq02pages = new RQ02_Pages(rq02_Driver);
            rq02pages.AllEnableAdvanceSearchOptionsareUnchecked();
        }
        //6th
        [Then(@"Enable search by catalog classification,Enable fuzzy logic search,Enable search history based on user profile check boxs should be disabled and unchecked for the admin user")]
        public void ThenEnableSearchByCatalogClassificationEnableFuzzyLogicSearchEnableSearchHistoryBasedOnUserProfileCheckBoxsShouldBeDisabledAndUncheckedForTheAdminUser()
        {
            rq02pages = new RQ02_Pages(rq02_Driver);
            rq02pages.AllEnableAdvanceSearchOptionsareDisabled();
        }
        //=========================================================
        // @RQ02_FA-30_tag6
        //3rd
        [When(@"user click on\(check\) the Enable search by catalog classification check box")]
        public void WhenUserClickOnCheckTheEnableSearchByCatalogClassificationCheckBox()
        {
            rq02pages = new RQ02_Pages(rq02_Driver);
            rq02pages.CheckTheEnableSearchByCatalogClassificationCheckBox();
                
        }

        // 4th
        [Then(@"Enable search result display based on catalog classification check box should be enable for the admin user")]
        public void ThenEnableSearchResultDisplayBasedOnCatalogClassificationCheckBoxShouldBeEnableForTheAdminUser()
        {
            rq02pages.EnableSearchResultDisplayBasedOnClassificationCheckBoxisEnabled();
        }

        //5th
        [When(@"user clicks on\(check\) the Enable search result display based on catalog classification check box")]
        public void WhenUserClicksOnCheckTheEnableSearchResultDisplayBasedOnCatalogClassificationCheckBox()
        {
            if(!rq02pages._chkBoxDisplayCatalogClassification.Selected)
            {
                rq02pages._chkBoxDisplayCatalogClassification.Click();
            }            
        }

        //6th
        [Then(@"system should dispaly the Enable search result display based on catalog classification check box as checked")]
        public void ThenSystemShouldDispalyTheEnableSearchResultDisplayBasedOnCatalogClassificationCheckBoxAsChecked()
        {
            rq02pages.displayEnableSearchResultDisplayBasedOnClassificationCheckBoxisChecked();
        }

        //7th
        [When(@"user click on\(uncheck\) the Enable search by catalog classification check box")]
        public void WhenUserClickOnUncheckTheEnableSearchByCatalogClassificationCheckBox()
        {
            rq02pages = new RQ02_Pages(rq02_Driver);
            rq02pages._chkBoxCatalogClassification.Click();
        }

        //8th
        [Then(@"Enable search result display based on catalog classification check box should be disable for the admin user")]
        public void ThenEnableSearchResultDisplayBasedOnCatalogClassificationCheckBoxShouldBeDisableForTheAdminUser()
        {
            rq02pages.EnableSearchResultDisplayBasedOnClassificationCheckBoxisDisabled();
        }



    }
}
