﻿using Microsoft.AspNetCore.DiagnosticsViewPage.Views;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;
using SpecFlowBDD_22.Framework;
using SpecFlowBDD_22.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpecFlowBDD_22.StepDefinitions
{
    [Binding]
    public class RQ03_StepDefinitions
    {
        public IWebDriver rq03_Driver;
        RQ02_Pages rq02pages;
        RQ05_Pages rq05pages;
        string searchtermresult;
        int title = 0;
        int briefDescription = 0;
        int fullDescription = 0;
        int keyword = 0;

        public RQ03_StepDefinitions(IWebDriver rDriver)
        {
            this.rq03_Driver = rDriver;
            //PageFactory.
        }

        RQ03_Pages rq03pages;
        WaitManager wait;

        //RQ03_Pages rq03pages = new RQ03_Pages(rq03_Driver);

        /*[When(@"Full description,Brief description and Keyword search terms check boxs are displayed as unchecked New")]
        public void WhenFullDescriptionBriefDescriptionAndKeywordSearchTermsCheckBoxsAreDisplayedAsUncheckedNew()
        {

            rq03pages = new RQ03_Pages(rq03_Driver);
            rq03pages.UncheckThreeBasicSearchTermParameterized("title","check");
        }*/


        [Given(@"end user is logged into the app portal and is on the Catalog Behavior Page")]
        public void GivenEndUserIsLoggedIntoTheAppPortalAndIsOnTheCatalogBehaviorPage()
        {
            Console.WriteLine("End User is logged into the application and navigated to Catalog Behavior Page");
        }

        [Then(@"Enable Catalog Classification search option should be displayed and enabled for the user")]
        public void ThenEnableCatalogClassificationSearchOptionShouldBeDisplayedAndEnabledForTheUser()
        {
            rq03pages = new RQ03_Pages(rq03_Driver);
            if (rq03pages._chkBoxEnableCatalogClassification.Enabled)
            {
                Console.WriteLine("Enable Catalog Classification Check Box is Enabled");
            }
            else
            {
                throw new Exception(string.Format("Enable Catalog Classification Check Box is not Enabled"));
            }
        }

        /*[When(@"Title search term check box is enabled and checked\(by default\)")]
        public void WhenTitleSearchTermCheckBoxIsEnabledAndCheckedByDefault()
        {
            rq02pages = new RQ02_Pages(rq03_Driver);
            rq02pages.VerifyTitleSearchTermsEnabledAndCheckedByDefault();
        }*/

        /*[When(@"Full description,Brief description and Keyword search terms check boxs are displayed as unchecked")]
        public void WhenFullDescriptionBriefDescriptionAndKeywordSearchTermsCheckBoxsAreDisplayedAsUnchecked()
        {
            rq03pages = new RQ03_Pages(rq03_Driver);
            //rq03pages.VerifyFullBriefKeywordSearchTermsIsUnchecked();
            AssertionManager.UnChecked(rq03pages._chkBoxBriefDescriptionSearch);
            AssertionManager.UnChecked(rq03pages._chkBoxFullDescriptionSearch);
            AssertionManager.UnChecked(rq03pages._chkBoxKeywordSearch);
        }*/

        /*[When(@"user provide the data\(related to the title search term\) in the search text box")]
        public void WhenUserProvideTheDataRelatedToTheTitleSearchTermInTheSearchTextBox()
        {
            rq03pages = new RQ03_Pages(rq03_Driver);
            rq03pages.TitleSearchTermDataInTheSearchTextBox();
        }*/

        /*[When(@"user clicks on the search icon from the app portal application")]
        public void WhenUserClicksOnTheSearchIconFromTheAppPortalApplication()
        {
            //Console.WriteLine("Already clicked on previous method");
            rq03pages = new RQ03_Pages(rq03_Driver);
            rq03pages.ClickOnSearchIcon();
            // rq03pages.ClickOnSearchIconButton();
        }*/

        /*[Then(@"system should display the search results according to the data provided in the search text box")]
        public void ThenSystemShouldDisplayTheSearchResultsAccordingToTheDataProvidedInTheSearchTextBox()
        {
            rq03pages = new RQ03_Pages(rq03_Driver);
            rq03pages.VerifySearchResult();
        }*/
        [When(@"user navigate to the browser catalog tab to perform the search")]
        public void WhenUserNavigateToTheBrowserCatalogTabToPerformTheSearch()
        {
            rq03pages = new RQ03_Pages(rq03_Driver);
            rq03pages._saveButton.Click();
            
            Thread.Sleep(1000);
            if (rq03pages._saveMessage.Text == "Settings Saved.")
            {
                Console.WriteLine("Saved message verified");
                rq03_Driver.SwitchTo().DefaultContent();
                rq03pages._browseCatalogTab.Click();
            }
            else
            {
                throw new Exception(string.Format("Saved message is not displayed"));
            }
            Thread.Sleep(3000);
        }

        [When(@"user search by the data related to the ""([^""]*)"" from the app portal application")]
        public void WhenUserSearchByTheDataRelatedToTheFromTheAppPortalApplication(string searchTerm)
        {
            // Thread.Sleep(3000);
            rq03pages = new RQ03_Pages(rq03_Driver);
            switch (searchTerm)
            {
                case "Full description":
                    rq03pages._textBoxInputMainSearchCatalog.Clear();
                    rq03pages._textBoxInputMainSearchCatalog.SendKeys("headset with an adjustable padded headband");
                    rq03pages._btnSearchButton.Click();
                    // Thread.Sleep(6000);
                    break;
                case "Brief description":
                    rq03pages._textBoxInputMainSearchCatalog.Clear();
                    rq03pages._textBoxInputMainSearchCatalog.SendKeys("Sony Mony Headset");
                    rq03pages._textBoxInputMainSearchCatalog.SendKeys(Keys.Enter);
                    // rq03pages._btnSearchButton.Click();
                    // wait.UntilIsElementIsNotDisplayed(By.XPath)
                    break;
                case "Keyword":
                    rq03pages._textBoxInputMainSearchCatalog.Clear();
                    rq03pages._textBoxInputMainSearchCatalog.SendKeys("My Microphone with Headphone");
                    rq03pages._textBoxInputMainSearchCatalog.SendKeys(Keys.Enter);
                    // Thread.Sleep(6000);
                    // rq03pages._btnSearchButton.Click();
                    break;
                case "Title":
                    rq03pages._textBoxInputMainSearchCatalog.Clear();
                    rq03pages._textBoxInputMainSearchCatalog.SendKeys("Box");
                    rq03pages._textBoxInputMainSearchCatalog.SendKeys(Keys.Enter);
                    // Thread.Sleep(6000);
                    //rq03pages._btnSearchButton.Click();
                    break;
            }
        }

        [When(@"user search by the data related to the ""([^""]*)"" from the app portal application for isEnabledSave")]
        public void WhenUserSearchByTheDataRelatedToTheFromTheAppPortalApplicationForIsEnabledSave(string searchTerm)
        {
            rq03pages = new RQ03_Pages(rq03_Driver);
            // rq05pages = new RQ05_Pages(rq03_Driver);
            switch (searchTerm)
            {
                case "Full description":
                    rq03pages._textBoxInputMainSearchCatalog.Clear();
                    rq03pages._textBoxInputMainSearchCatalog.SendKeys(RQ05_Pages.selectedTitleText);
                    rq03pages._btnSearchButton.Click();
                    // Thread.Sleep(6000);
                    break;
                case "Brief description":
                    rq03pages._textBoxInputMainSearchCatalog.Clear();
                    rq03pages._textBoxInputMainSearchCatalog.SendKeys("Sony Mony Headset");
                    rq03pages._textBoxInputMainSearchCatalog.SendKeys(Keys.Enter);
                    // rq03pages._btnSearchButton.Click();
                    // wait.UntilIsElementIsNotDisplayed(By.XPath)
                    break;
                case "Keyword":
                    rq03pages._textBoxInputMainSearchCatalog.Clear();
                    rq03pages._textBoxInputMainSearchCatalog.SendKeys("My Microphone with Headphone");
                    rq03pages._textBoxInputMainSearchCatalog.SendKeys(Keys.Enter);
                    // Thread.Sleep(6000);
                    // rq03pages._btnSearchButton.Click();
                    break;
                case "Title":
                    rq03pages._textBoxInputMainSearchCatalog.Clear();
                    rq03pages._textBoxInputMainSearchCatalog.SendKeys(RQ05_Pages.selectedTitleText);
                    rq03pages._textBoxInputMainSearchCatalog.SendKeys(Keys.Enter);
                    // Thread.Sleep(6000);
                    //rq03pages._btnSearchButton.Click();
                    break;
            }
        }


        [When(@"user search by the typo/misspelled data ""([^""]*)"" related to the ""([^""]*)"" from the app portal application")]
        public void WhenUserSearchByTheTypoMisspelledDataRelatedToTheFromTheAppPortalApplication(string misspelledData, string basicSearchTermList)
        {
            rq03pages = new RQ03_Pages(rq03_Driver);
            string[] searchTerm = basicSearchTermList.Split(',');
            foreach (var term in searchTerm)
            {
                switch (term)
                {
                    case "Full description":
                        rq03pages._textBoxInputMainSearchCatalog.Clear();
                        rq03pages._textBoxInputMainSearchCatalog.SendKeys(misspelledData);
                        rq03pages._btnSearchButton.Click();
                        break;
                    case "Brief description":
                        rq03pages._textBoxInputMainSearchCatalog.Clear();
                        rq03pages._textBoxInputMainSearchCatalog.SendKeys(misspelledData);
                        rq03pages._btnSearchButton.Click();
                        break;
                    case "Keyword":
                        rq03pages._textBoxInputMainSearchCatalog.Clear();
                        rq03pages._textBoxInputMainSearchCatalog.SendKeys(misspelledData);
                        rq03pages._textBoxInputMainSearchCatalog.SendKeys(Keys.Enter);
                        // rq03pages._btnSearchButton.Click();
                        break;
                    case "Title":
                        rq03pages._textBoxInputMainSearchCatalog.Clear();
                        rq03pages._textBoxInputMainSearchCatalog.SendKeys(misspelledData);
                        Thread.Sleep(2000);
                        rq03pages._textBoxInputMainSearchCatalog.SendKeys(Keys.Enter);
                        //rq03pages._btnSearchButton.Click();
                        break;
                }
            }
        }

        [Then(@"system should display the search results according to the typo/misspelled data ""([^""]*)"" provided in ""([^""]*)"" search text box")]
        public void ThenSystemShouldDisplayTheSearchResultsAccordingToTheTypoMisspelledDataProvidedInSearchTextBox(string searchTermData, string searchTerm)
        {
            Thread.Sleep(5000);
            searchtermresult = rq03pages._displaySearchResult.Text.Replace('"', ' ').Trim();
            rq03pages = new RQ03_Pages(rq03_Driver);
            if (searchTerm == "Title")
            {
                Assert.AreEqual(searchTermData, searchtermresult, "The search term result displayed is incorrect");
                rq03pages.VerifySearchResult();
            }
            else if (searchTerm == "Full description")
            {
                Assert.AreEqual(searchTermData, searchtermresult, "The search term result displayed is incorrect");
                rq03pages.VerifySearchResult();
            }
            else if (searchTerm == "Brief description")
            {
                Assert.AreEqual(searchTermData, searchtermresult, "The search term result displayed is incorrect");
                rq03pages.VerifySearchResult();
            }
            else if (searchTerm == "Keyword")
            {
                Assert.AreEqual(searchTermData, searchtermresult, "The search term result displayed is incorrect");
                rq03pages.VerifySearchResult();
            }
        }

        [Then(@"system should display the search results according to the data provided ""([^""]*)"" in the search text box")]
        public void ThenSystemShouldDisplayTheSearchResultsAccordingToTheDataProvidedInTheSearchTextBox(string searchTermResult)
        {
            Thread.Sleep(15000);
            searchtermresult = rq03pages._displaySearchResult.Text.Replace('"', ' ').Trim();
            rq03pages = new RQ03_Pages(rq03_Driver);
            if(searchTermResult=="Title")
            {
                Assert.AreEqual("Box", searchtermresult, "The search term result displayed is incorrect");
                rq03pages.VerifySearchResult();
            }
            else if (searchTermResult == "Full description")
            {
                Assert.AreEqual("headset with an adjustable padded headband", searchtermresult, "The search term result displayed is incorrect");
                rq03pages.VerifySearchResult();
            }
            else if (searchTermResult == "Brief description")
            {
                Assert.AreEqual("Sony Mony Headset", searchtermresult, "The search term result displayed is incorrect");
                rq03pages.VerifySearchResult();
            }
            else if (searchTermResult == "Keyword")
            {
                Assert.AreEqual("My Microphone with Headphone", searchtermresult, "The search term result displayed is incorrect");
                rq03pages.VerifySearchResult();
            }
        }



        [Then(@"system should not display the search results for the data provided ""([^""]*)"" search term")]
        public void ThenSystemShouldNotDisplayTheSearchResultsForTheDataProvidedSearchTerm(string searchTerm)
        {
            Thread.Sleep(20000);
            WebDriverWait wait = new WebDriverWait(rq03_Driver, TimeSpan.FromSeconds(20));
            rq03pages = new RQ03_Pages(rq03_Driver);
            searchtermresult = rq03pages._displaySearchResult.Text.Replace('"', ' ').Trim();
            //wait.UntilIsElementIsDisplayed(By.XPath("//div//h1[contains(text(),'" + searchtermresult + "')]"));
                     

            wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("//div//h1[contains(text(),'" + searchtermresult + "')]")));


            switch (searchTerm)
            {
                case "Full description":
                    // AssertionManager.ElementTextEquals(rq03pages._displaySearchResult, "Full");
                    Assert.AreEqual("headset with an adjustable padded headband", searchtermresult, "The search term result displayed is incorrect");
                    AssertionManager.ElementTextEquals(rq03pages._notFoundMessage, "There was no result for your search.");
                    break;
                case "Brief description":
                    Assert.AreEqual("Sony Mony Headset", searchtermresult, "The search term result displayed is incorrect");
                    AssertionManager.ElementTextEquals(rq03pages._notFoundMessage, "There was no result for your search.");
                    break;
                case "Keyword":
                    Assert.AreEqual("My Microphone with Headphone", searchtermresult, "The search term result displayed is incorrect");
                    AssertionManager.ElementTextEquals(rq03pages._notFoundMessage, "There was no result for your search.");
                    break;
                case "Title":

                    Assert.AreEqual("Box", searchtermresult, "The search term result displayed is incorrect");
                    AssertionManager.ElementTextEquals(rq03pages._notFoundMessage, "There was no result for your search.");
                    break;
            }
        }

        [Then(@"system should not display the search results for the data provided ""([^""]*)"" search term  for isEnabledSave")]
        public void ThenSystemShouldNotDisplayTheSearchResultsForTheDataProvidedSearchTermForIsEnabledSave(string searchTerm)
        {
            Thread.Sleep(10000);
            WebDriverWait wait = new WebDriverWait(rq03_Driver, TimeSpan.FromSeconds(20));
            rq03pages = new RQ03_Pages(rq03_Driver);
            searchtermresult = rq03pages._displaySearchResult.Text.Replace('"', ' ').Trim();
            //wait.UntilIsElementIsDisplayed(By.XPath("//div//h1[contains(text(),'" + searchtermresult + "')]"));


            wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("//div//h1[contains(text(),'" + searchtermresult + "')]")));


            switch (searchTerm)
            {
                case "Full description":
                    // AssertionManager.ElementTextEquals(rq03pages._displaySearchResult, "Full");
                    Assert.AreEqual("headset with an adjustable padded headband", searchtermresult, "The search term result displayed is incorrect");
                    AssertionManager.ElementTextEquals(rq03pages._notFoundMessage, "There was no result for your search.");
                    break;
                case "Brief description":
                    Assert.AreEqual("Sony Mony Headset", searchtermresult, "The search term result displayed is incorrect");
                    AssertionManager.ElementTextEquals(rq03pages._notFoundMessage, "There was no result for your search.");
                    break;
                case "Keyword":
                    Assert.AreEqual("My Microphone with Headphone", searchtermresult, "The search term result displayed is incorrect");
                    AssertionManager.ElementTextEquals(rq03pages._notFoundMessage, "There was no result for your search.");
                    break;
                case "Title":

                    Assert.AreEqual(RQ05_Pages.selectedTitleText, searchtermresult, "The search term result displayed is incorrect");
                    AssertionManager.ElementTextEquals(rq03pages._notFoundMessage, "There was no result for your search.");
                    break;
            }
        }




        [When(@"user provide the data\(related to the Full description,Brief description and Keyword search terms\) in the search text box")]
        public void WhenUserProvideTheDataRelatedToTheFullDescriptionBriefDescriptionAndKeywordSearchTermsInTheSearchTextBox()
        {
            rq03pages = new RQ03_Pages(rq03_Driver);
            rq03pages.VerifySearchResultForBriefFullKeywordSearch();
            //rq03pages.BriefSearchTermDataInTheSearchTextBox();
        }

        [Then(@"system should not display the search results for the data provided in the search text box")]
        public void ThenSystemShouldNotDisplayTheSearchResultsForTheDataProvidedInTheSearchTextBox()
        {
            Console.WriteLine("Data already Verified on previous method");
            // rq03pages.BriefSearchTermNotValidDataInTheSearchTextBox();
        }
        //===========================Below Added for Scenario03============================================================

        /*[When(@"user click\(uncheck\) on the Title search term check box")]
        public void WhenUserClickUncheckOnTheTitleSearchTermCheckBox()
        {
            rq03pages = new RQ03_Pages(rq03_Driver);
            rq03pages.UncheckTitleSearchTerm();
        }*/

        /*[When(@"user click\(check\) on the Full description search term check box")]
        public void WhenUserClickCheckOnTheFullDescriptionSearchTermCheckBox()
        {
            rq03pages = new RQ03_Pages(rq03_Driver);
            rq03pages.CheckFullDescriptionSearchTerm();

        }*/

        [When(@"Title,Brief description and Keyword search terms check boxs are displayed as unchecked")]
        public void WhenTitleBriefDescriptionAndKeywordSearchTermsCheckBoxsAreDisplayedAsUnchecked()
        {
            // just verify that checkboxes are unchecked or not, If not then through exception 
            rq03pages.UncheckTitleSearchTerm();
            rq03pages.UncheckBriefDescriptionSearchTerm();
            rq03pages.UncheckKeywordSearchTerm();
            rq03pages.SaveAndVerify();
            rq03pages.NavigateToBrowseCatalogTab();
        }

        /*[When(@"user provide the data\(related to the Full description search term\) in the search text box")]
        public void WhenUserProvideTheDataRelatedToTheFullDescriptionSearchTermInTheSearchTextBox()
        {
            rq03pages.SearchTermDataInTheSearchTextBox("Full");
        }*/

        /*[When(@"user clicks on the search icon from the app portal application")]
        public void WhenUserClicksOnTheSearchIconFromTheAppPortalApplication()
        {
            rq03pages.ClickOnSearchIconButton();
        }*/

        /*[Then(@"System should not display any results, when user search by the Title,Brief description and Keyword search terms in the search text box")]
        public void ThenSystemShouldNotDisplayAnyResultsWhenUserSearchByTheTitleBriefDescriptionAndKeywordSearchTermsInTheSearchTextBox()
        {
            rq03pages.SearchTermDataInTheSearchTextBox("Klassic");
            rq03pages.ClickOnSearchIconButton();
            rq03pages.verifyUncheckInvalidSearchTermData("Klassic");


            rq03pages.SearchTermDataInTheSearchTextBox("SonyMony");
            rq03pages.ClickOnHitEnterButtonFromKeyboard();
            rq03pages.verifyUncheckInvalidSearchTermData("SonyMony");

            rq03pages.SearchTermDataInTheSearchTextBox("My Microphone");
            rq03pages.ClickOnHitEnterButtonFromKeyboard();
            rq03pages.verifyUncheckInvalidSearchTermData("My Microphone");
        }*/


        /*[When(@"user provide the data\(related to the Title,Brief description and Keyword search terms\) in the search text box")]
        public void WhenUserProvideTheDataRelatedToTheTitleBriefDescriptionAndKeywordSearchTermsInTheSearchTextBox()
        {
            rq03pages.SearchTermDataInTheSearchTextBox("Klassic");
            rq03pages.ClickOnSearchIconButton();
            rq03pages.verifyUncheckInvalidSearchTermData("Klassic");


            rq03pages.SearchTermDataInTheSearchTextBox("SonyMony");
            rq03pages.ClickOnHitEnterButtonFromKeyboard();
            rq03pages.verifyUncheckInvalidSearchTermData("SonyMony");

            rq03pages.SearchTermDataInTheSearchTextBox("My Microphone");
            rq03pages.ClickOnHitEnterButtonFromKeyboard();
            rq03pages.verifyUncheckInvalidSearchTermData("My Microphone");
        }*/
        //===========================Below Added for Scenario04============================================================ 

        /*[When(@"user click\(check\) on the brief description search term check box")]
        public void WhenUserClickCheckOnTheBriefDescriptionSearchTermCheckBox()
        {
            rq03pages = new RQ03_Pages(rq03_Driver);
            rq03pages.CheckBriefDescriptionSearchTerm();
        }*/

        [When(@"Title,Full description and Keyword search terms check boxs are displayed as unchecked")]
        public void WhenTitleFullDescriptionAndKeywordSearchTermsCheckBoxsAreDisplayedAsUnchecked()
        {
            rq03pages.UncheckTitleSearchTerm();
            rq03pages.UncheckFullDescriptionSearchTerm();
            rq03pages.UncheckKeywordSearchTerm();
            rq03pages.SaveAndVerify();
            rq03pages.NavigateToBrowseCatalogTab();
        }

        [When(@"user provide the data\(related to the brief description search term\) in the search text box")]
        public void WhenUserProvideTheDataRelatedToTheBriefDescriptionSearchTermInTheSearchTextBox()
        {
            rq03pages.SearchTermDataInTheSearchTextBox("SonyMony Headset");
        }

        [Then(@"System should not display any results, when user search by the Title,full description and Keyword search terms in the search text box")]
        public void ThenSystemShouldNotDisplayAnyResultsWhenUserSearchByTheTitleFullDescriptionAndKeywordSearchTermsInTheSearchTextBox()
        {
            rq03pages.SearchTermDataInTheSearchTextBox("Box");
            rq03pages.ClickOnSearchIconButton();
            rq03pages.verifyUncheckInvalidSearchTermData("Box");

            rq03pages.SearchTermDataInTheSearchTextBox("all-purpose headset with an adjustable");
            rq03pages.ClickOnHitEnterButtonFromKeyboard();
            rq03pages.verifyUncheckInvalidSearchTermData("all-purpose headset with an adjustable");

            rq03pages.SearchTermDataInTheSearchTextBox("My Microphone");
            rq03pages.ClickOnHitEnterButtonFromKeyboard();
            rq03pages.verifyUncheckInvalidSearchTermData("My Microphone");
        }


        /*[When(@"user provide the data\(related to the Title,full description and Keyword search terms\) in the search text box")]
        public void WhenUserProvideTheDataRelatedToTheTitleFullDescriptionAndKeywordSearchTermsInTheSearchTextBox()
        {
            rq03pages.SearchTermDataInTheSearchTextBox("Klassic");
            rq03pages.ClickOnSearchIconButton();
            rq03pages.verifyUncheckInvalidSearchTermData("Klassic");

            rq03pages.SearchTermDataInTheSearchTextBox("all-purpose headset with an adjustable");
            rq03pages.ClickOnHitEnterButtonFromKeyboard();
            rq03pages.verifyUncheckInvalidSearchTermData("all-purpose headset with an adjustable");

            rq03pages.SearchTermDataInTheSearchTextBox("My Microphone");
            rq03pages.ClickOnHitEnterButtonFromKeyboard();
            rq03pages.verifyUncheckInvalidSearchTermData("My Microphone");
        }*/

        //===========================Below Added for Scenario04============================================================ 

        /*[When(@"user click\(check\) on the keyword search term check box")]
        public void WhenUserClickCheckOnTheKeywordSearchTermCheckBox()
        {
            rq03pages = new RQ03_Pages(rq03_Driver);
            rq03pages.CheckKeywordSearchTerm();
        }*/

        [When(@"Title,Full description and brief description search terms check boxs are displayed as unchecked")]
        public void WhenTitleFullDescriptionAndBriefDescriptionSearchTermsCheckBoxsAreDisplayedAsUnchecked()
        {
            rq03pages.UncheckTitleSearchTerm();
            rq03pages.UncheckFullDescriptionSearchTerm();
            rq03pages.UncheckBriefDescriptionSearchTerm();
            rq03pages.SaveAndVerify();
            rq03pages.NavigateToBrowseCatalogTab();
        }

        [When(@"user provide the data\(related to the keyword search term\) in the search text box")]
        public void WhenUserProvideTheDataRelatedToTheKeywordSearchTermInTheSearchTextBox()
        {
            rq03pages.SearchTermDataInTheSearchTextBox("My Microphone with Headphone");
        }

        [Then(@"System should not display any results, when user search by the Title,full description and brief description search terms in the search text box")]
        public void ThenSystemShouldNotDisplayAnyResultsWhenUserSearchByTheTitleFullDescriptionAndBriefDescriptionSearchTermsInTheSearchTextBox()
        {
            rq03pages.SearchTermDataInTheSearchTextBox("Box");
            rq03pages.ClickOnSearchIconButton();
            Thread.Sleep(1000);
            rq03pages.verifyUncheckInvalidSearchTermData("Box");

            rq03pages.SearchTermDataInTheSearchTextBox("all-purpose headset with an adjustable");
            rq03pages.ClickOnHitEnterButtonFromKeyboard();
            Thread.Sleep(1000);
            rq03pages.verifyUncheckInvalidSearchTermData("all-purpose headset with an adjustable");

            rq03pages.SearchTermDataInTheSearchTextBox("SonyMony Headset");
            rq03pages.ClickOnHitEnterButtonFromKeyboard();
            Thread.Sleep(1000);
            rq03pages.verifyUncheckInvalidSearchTermData("SonyMony Headset");
        }


        /*[When(@"user provide the data\(related to the Title,full description and brief description search terms\) in the search text box")]
        public void WhenUserProvideTheDataRelatedToTheTitleFullDescriptionAndBriefDescriptionSearchTermsInTheSearchTextBox()
        {
            rq03pages.SearchTermDataInTheSearchTextBox("Klassic");
            rq03pages.ClickOnSearchIconButton();
            rq03pages.verifyUncheckInvalidSearchTermData("Klassic");

            rq03pages.SearchTermDataInTheSearchTextBox("all-purpose headset with an adjustable");
            rq03pages.ClickOnHitEnterButtonFromKeyboard();
            rq03pages.verifyUncheckInvalidSearchTermData("all-purpose headset with an adjustable");

            rq03pages.SearchTermDataInTheSearchTextBox("SonyMony Headset");
            rq03pages.ClickOnHitEnterButtonFromKeyboard();
            rq03pages.verifyUncheckInvalidSearchTermData("SonyMony Headset");
        }*/

        //===========================Below Added for Scenario10============================================================ 

        /*[Then(@"Enable advance search options check box should be checked\(by default\)")]
        public void ThenEnableAdvanceSearchOptionsCheckBoxShouldBeCheckedByDefault()
        {
            rq03pages.EnableAdvanceSearchOptionsChkBoxCheckedByDefault();
        }*/

        [Then(@"system should dispaly the Enable search by catalog classification check box as checked")]
        public void ThenSystemShouldDispalyTheEnableSearchByCatalogClassificationCheckBoxAsChecked()
        {
            rq03pages.EnableSearchByCatalogClassificationChkBoxShouldDisplayAsChecked();
            
        }

        [When(@"user navigate to the Catalog Classification page\(Admin >> Site Management >> Settings >> Web Site >> Catalog Classification page\)")]
        public void WhenUserNavigateToTheCatalogClassificationPageAdminSiteManagementSettingsWebSiteCatalogClassificationPage()
        {
            rq03pages = new RQ03_Pages(rq03_Driver);
            rq03pages.NavigateToTheCatalogClassificationPageTab();
        }

        [When(@"user click on\(check\) the Enable Catalog Classification check box")]
        public void WhenUserClickOnCheckTheEnableCatalogClassificationCheckBox()
        {
            rq03pages = new RQ03_Pages(rq03_Driver);
            rq03pages.CheckEnableCatalogClassificationChkBox();
        }

        [When(@"user click on save button and confirm the message")]
        public void WhenUserClickOnSaveButtonAndConfirmTheMessage()
        {
            rq03pages = new RQ03_Pages(rq03_Driver);
            rq03pages.SaveAndVerify();
        }



        [When(@"user click on\(Uncheck\) the Catalog Classification check box")]
        public void WhenUserClickOnUncheckTheCatalogClassificationCheckBox()
        {
            rq03pages = new RQ03_Pages(rq03_Driver);
            rq03pages.UncheckEnableCatalogClassificationChkBox();
        }

        [Then(@"system should display the Enable Catalog Classification search option check box as unchecked")]
        public void ThenSystemShouldDisplayTheEnableCatalogClassificationSearchOptionCheckBoxAsUnchecked()
        {
            rq03pages = new RQ03_Pages(rq03_Driver);
            AssertionManager.UnChecked(rq03pages._chkBoxEnableCatalogClassification);
        }



        /*[When(@"user click on Save button and verify the message")]
        public void WhenUserClickOnSaveButtonAndVerifyTheMessage()
        {
            rq03pages.SaveAndVerify();
        }*/


        [Then(@"system should display the Enable Catalog Classification search option check box as checked")]
        public void ThenSystemShouldDisplayTheEnableCatalogClassificationSearchOptionCheckBoxAsChecked()
        {
            rq03pages = new RQ03_Pages(rq03_Driver);
            rq03pages.DisplayEnableCatalogClassificationChkBoxAsChecked();
        }

        /*[When(@"user click on Browse Catalog tab and navigate to search page")]
        public void WhenUserClickOnBrowseCatalogTabAndNavigateToSearchPage()
        {
            rq03pages.NavigateToBrowseCatalogTab();
        }*/

        /*[When(@"Title,Brief description and Keyword search terms check boxes are unchecked")]
        public void WhenTitleBriefDescriptionAndKeywordSearchTermsCheckBoxesAreUnchecked()
        {
            rq03pages.TitleBriefDescriptionAndKeywordSearchTermsCheckBoxesAreUnchecked();
        }*/

        /*[Then(@"user should be able to see the classification option selected in the sort dropdown box")]
        public void ThenUserShouldBeAbleToSeeTheClassificationOptionSelectedInTheSortDropdownBox(String )
        {
            rq03pages.VerifyParameterOptionIsSelectedInTheSortDropdownBox("Classification");
        }*/

        [Then(@"user should be able to see the ""([^""]*)"" option selected in the sort dropdown box")]
        public void ThenUserShouldBeAbleToSeeTheOptionSelectedInTheSortDropdownBox(string sortByInDropDownBox)
        {
            rq03pages = new RQ03_Pages(rq03_Driver);
            rq03pages.VerifyParameterOptionIsSelectedInTheSortDropdownBox(sortByInDropDownBox);
        }


        [Then(@"user should not be able to see the ""([^""]*)"" option selected in the sort dropdown box")]
        public void ThenUserShouldNotBeAbleToSeeTheOptionSelectedInTheSortDropdownBox(string sortByInDropDownBox)
        {
            rq03pages = new RQ03_Pages(rq03_Driver);
            rq03pages.VerifyParameterOptionIsNotSelectedInTheSortDropdownBox(sortByInDropDownBox);
        }

        [Then(@"all the search results should be automatically sorted by the alphabetically and not by classifications")]
        public void ThenAllTheSearchResultsShouldBeAutomaticallySortedByTheAlphabeticallyAndNotByClassifications()
        {
            rq03pages = new RQ03_Pages(rq03_Driver);
            rq03pages.AllTheSearchResultsShouldBeAutomaticallySortedByTheAlphabeticallyAndNotByClassifications();
        }



        [Then(@"all the search results should be automatically sorted by the catalog classification")]
        public void ThenAllTheSearchResultsShouldBeAutomaticallySortedByTheCatalogClassification()
        {
            rq05pages = new RQ05_Pages(rq03_Driver);
            rq05pages.VerifyAllThePreferredNon_ClassifiedNon_PreferredCatalogItemsCatalogItemsShouldBeSortedAlphabeticallyInRespectiveClassifications();
        }


        [Then(@"user should be able to see the \(Title:a-z\) option selected in the sort dropdown box")]
        public void ThenUserShouldBeAbleToSeeTheTitleA_ZOptionSelectedInTheSortDropdownBox()
        {
            rq03pages = new RQ03_Pages(rq03_Driver);
            rq03pages.VerifyParameterOptionIsSelectedInTheSortDropdownBox("Title:a-z");
        }

        // =====================================For Scenario 12==============================
        /*[When(@"user provide the typo/misspelled data\(related to the title search term\) in the search text box")]
        public void WhenUserProvideTheTypoMisspelledDataRelatedToTheTitleSearchTermInTheSearchTextBox()
        {
            rq03pages.SearchTermDataInTheSearchTextBox("Aps");
        }*/

        // =====================================For Scenario 13==============================
        [When(@"user provide the typo/misspelled data\(related to the Full description search term\) in the search text box")]
        public void WhenUserProvideTheTypoMisspelledDataRelatedToTheFullDescriptionSearchTermInTheSearchTextBox()
        {
            rq03pages = new RQ03_Pages(rq03_Driver);
            rq03pages.SearchTermDataInTheSearchTextBox("fuill");
        }

        // =====================================For Scenario 14==============================
        [When(@"user provide the typo/misspelled data\(related to the brief description search term\) in the search text box")]
        public void WhenUserProvideTheTypoMisspelledDataRelatedToTheBriefDescriptionSearchTermInTheSearchTextBox()
        {
            rq03pages = new RQ03_Pages(rq03_Driver);
            rq03pages.SearchTermDataInTheSearchTextBox("mecro");
        }

        // =====================================For Scenario 15==============================
        [When(@"user provide the typo/misspelled data\(related to the keyword search term\) in the search text box")]
        public void WhenUserProvideTheTypoMisspelledDataRelatedToTheKeywordSearchTermInTheSearchTextBox()
        {
            rq03pages = new RQ03_Pages(rq03_Driver);
            rq03pages.SearchTermDataInTheSearchTextBox("mecro");
        }

    }
}
