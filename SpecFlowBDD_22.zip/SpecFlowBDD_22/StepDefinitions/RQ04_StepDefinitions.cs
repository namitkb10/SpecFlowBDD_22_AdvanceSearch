﻿using AngleSharp.Dom;
using Dynamitey.DynamicObjects;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;
using SpecFlowBDD_22.Framework;
using SpecFlowBDD_22.HooksManager;
using SpecFlowBDD_22.Pages;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SpecFlowBDD_22.CommonClass;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Edge;
using OpenQA.Selenium.Firefox;
using WebDriverManager.DriverConfigs.Impl;
using WindowsInput.Native;
using WindowsInput;

namespace SpecFlowBDD_22.StepDefinitions
{
    [Binding]
    public class RQ04_StepDefinitions
    {
        public IWebDriver rq04_Driver;
        // public IWebDriver rq04_Driver;
        RQ05_Pages rq05pages;
        RQ04_Pages rq04pages;
        RQ03_Pages rq03pages;
        RQ06_Pages rq06pages;
        string searchtermresult;
        string query;
        int max = 0;
        ClassCommon cc = new ClassCommon();
        public RQ04_StepDefinitions(IWebDriver rDriver)
        {
            this.rq04_Driver = rDriver;
            //PageFactory.
        }



        [When(@"user ensure the ""([^""]*)"" advance search checkbox\(is Checked\)")]
        public void WhenUserEnsureTheAdvanceSearchCheckboxIsChecked(string advanceSearchTerm)
        {
            rq04pages = new RQ04_Pages(rq04_Driver);

            rq04pages = new RQ04_Pages(rq04_Driver);
            string[] searchTerm = advanceSearchTerm.Split(',');
            foreach (var term in searchTerm)
            {
                switch (term)
                {
                    case "Fuzzy":
                        if (!rq04pages._chkBoxFuzzySearch.Selected)
                        {
                            rq04pages._chkBoxFuzzySearch.Click();
                        }
                        break;
                    case "History":
                        if (!rq04pages._chkBoxHistorySearch.Selected)
                        {
                            rq04pages._chkBoxHistorySearch.Click();
                        }
                        break;
                }
            }
        }

        [When(@"user provide the typo/misspelled data ""([^""]*)"" related to the from the app portal application")]
        public void WhenUserProvideTheTypoMisspelledDataRelatedToTheFromTheAppPortalApplication(string misspelledData)
        {
            rq03pages = new RQ03_Pages(rq04_Driver);
            rq03pages._textBoxInputMainSearchCatalog.Clear();

            foreach (char ch in misspelledData)
            {
                rq03pages._textBoxInputMainSearchCatalog.SendKeys(ch.ToString());
                Thread.Sleep(1000);
            }
/*

            string[] strArrMisspelledData = misspelledData.Split('');
            if (strArrMisspelledData.Length > 0)
            {
                for (int i=0; i< strArrMisspelledData.Length;i++) {
                    rq03pages._textBoxInputMainSearchCatalog.SendKeys(strArrMisspelledData[i]);
                    Thread.Sleep(400);
                }
            }*/

            // Console.WriteLine("Count ");
        }

        [Then(@"system should display the search suggestions on the app portal page")]
        public void ThenSystemShouldDisplayTheSearchSuggestionsOnTheAppPortalPage()
        {
            rq04pages = new RQ04_Pages(rq04_Driver);
            Thread.Sleep(5000);
            IList<IWebElement> lstWebElement = rq04_Driver.FindElements(By.XPath("//li[@class='ui-menu-item']/a[@class='ui-corner-all']"));
            if (lstWebElement.Count > 0)
            {
                foreach (IWebElement element in lstWebElement)
                {
                    Console.WriteLine(element.Text);
                }
            }
            else
            {
                throw new Exception(string.Format("Auto Search Suggestions are not displayed"));
            }
        }

        [Then(@"system should display max (.*) search list suggestions")]
        public void ThenSystemShouldDisplayMaxSearchListSuggestions(int value)
        {
            IList<IWebElement> lstWebElement = rq04_Driver.FindElements(By.XPath("//li[@class='ui-menu-item']/a[@class='ui-corner-all']"));
            if (lstWebElement.Count > value)
            {
                throw new Exception(string.Format("Total list count is " + lstWebElement.Count + ", Where as Suggestions List Count Should not display more than 10"));
            }
        }

        [Then(@"system should display zero search list suggestions")]
        public void ThenSystemShouldDisplayZeroSearchListSuggestions()
        {
            IList<IWebElement> lstWebElement = rq04_Driver.FindElements(By.XPath("//li[@class='ui-menu-item']/a[@class='ui-corner-all']"));
            if (lstWebElement.Count == 0)
            {
                Console.WriteLine("Total list count is " + lstWebElement.Count);
            }
            else
            {
                throw new Exception(string.Format("Total list count is " + lstWebElement.Count + ", Where as Suggestions List Count Should be zero"));
            }
        }

        [When(@"user provide the data related to the ""([^""]*)"" from the app portal application")]
        public void WhenUserProvideTheDataRelatedToTheFromTheAppPortalApplication(string searchTerm)
        {
            rq03pages = new RQ03_Pages(rq04_Driver);
            switch (searchTerm)
            {
                case "Full description":
                    rq03pages._textBoxInputMainSearchCatalog.Clear();
                    rq03pages._textBoxInputMainSearchCatalog.SendKeys("headset with an adjustable padded headband");
                    break;
                case "Brief description":
                    rq03pages._textBoxInputMainSearchCatalog.Clear();
                    rq03pages._textBoxInputMainSearchCatalog.SendKeys("Sony Mony Headset");
                    break;
                case "Keyword":
                    rq03pages._textBoxInputMainSearchCatalog.Clear();
                    rq03pages._textBoxInputMainSearchCatalog.SendKeys("My Microphone with Headphone");
                    break;
                case "Title":
                    rq03pages._textBoxInputMainSearchCatalog.Clear();
                    rq03pages._textBoxInputMainSearchCatalog.SendKeys("Box Account 1");
                    break;
            }
        }

        [When(@"user provide the data related to the ""([^""]*)"" from the app portal application ""([^""]*)""")]
        public void WhenUserProvideTheDataRelatedToTheFromTheAppPortalApplication(string searchTerm, string catalogType)
        {
            rq03pages = new RQ03_Pages(rq04_Driver);
            switch (searchTerm)
            {
                case "Full description":
                    rq03pages._textBoxInputMainSearchCatalog.Clear();
                    rq03pages._textBoxInputMainSearchCatalog.SendKeys("headset with an adjustable padded headband");
                    break;
                case "Brief description":
                    rq03pages._textBoxInputMainSearchCatalog.Clear();
                    rq03pages._textBoxInputMainSearchCatalog.SendKeys("Sony Mony Headset");
                    break;
                case "Keyword":
                    rq03pages._textBoxInputMainSearchCatalog.Clear();
                    rq03pages._textBoxInputMainSearchCatalog.SendKeys("My Microphone with Headphone");
                    break;
                case "Title":
                    rq03pages._textBoxInputMainSearchCatalog.Clear();
                    if(catalogType== "preferred")
                    {
                        rq03pages._textBoxInputMainSearchCatalog.SendKeys(cc.getDataFromFile("ip_rq04_preferred"));
                    }
                    else if(catalogType=="nonClassifed")
                    {
                        rq03pages._textBoxInputMainSearchCatalog.SendKeys(cc.getDataFromFile("ip_rq04__nonClassified"));
                    }
                    else if (catalogType == "nonPreferred")
                    {
                        rq03pages._textBoxInputMainSearchCatalog.SendKeys(cc.getDataFromFile("ip_rq04_nonPreferred"));
                    }
                    break;
            }
        }


        [When(@"user ensure the ""([^""]*)"" advance search checkbox\(is Unchecked\)")]
        public void WhenUserEnsureTheAdvanceSearchCheckboxIsUnchecked(string advanceSearchTerm)
            {
                // Thread.Sleep(5000);
                // searchtermresult = rq03pages._displaySearchResult.Text.Replace('"', ' ').Trim();
                rq04pages = new RQ04_Pages(rq04_Driver);
                string[] searchTerm = advanceSearchTerm.Split(',');
                foreach (var term in searchTerm)
                {
                    switch (term)
                    {
                        case "Fuzzy":
                            if (rq04pages._chkBoxFuzzySearch.Selected)
                            {
                                rq04pages._chkBoxFuzzySearch.Click();
                            }
                            break;
                        case "History":
                            if (rq04pages._chkBoxHistorySearch.Selected)
                            {
                                rq04pages._chkBoxHistorySearch.Click();
                            }
                            break;
                            /*case "Keyword":
                                if (rq04pages._chkBoxKeywordSearch.Selected)
                                {
                                    rq04pages._chkBoxKeywordSearch.Click();
                                }
                                break;
                            case "Title":
                                if (rq04pages._chkBoxTitleSearch.Selected)
                                {
                                    rq04pages._chkBoxTitleSearch.Click();
                                }
                                break;*/
                    }
                }
            }

        [Then(@"system should not display the search results for the ""([^""]*)"" data provided for ""([^""]*)"" search term")]
        public void ThenSystemShouldNotDisplayTheSearchResultsForTheDataProvidedForSearchTerm(string searchData, string searchTerm)
            {
                Thread.Sleep(20000);
                WebDriverWait wait = new WebDriverWait(rq04_Driver, TimeSpan.FromSeconds(20));
                rq03pages = new RQ03_Pages(rq04_Driver);
                rq04pages = new RQ04_Pages(rq04_Driver);

                searchtermresult = rq03pages._displaySearchResult.Text.Replace('"', ' ').Trim();
                //wait.UntilIsElementIsDisplayed(By.XPath("//div//h1[contains(text(),'" + searchtermresult + "')]"));

                
                wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("//div//h1[contains(text(),'" + searchtermresult + "')]")));


                switch (searchTerm)
                {
                    case "Full description":
                        // AssertionManager.ElementTextEquals(rq03pages._displaySearchResult, "Full");
                        Assert.AreEqual(searchData, searchtermresult, "The search term result displayed is incorrect");
                        AssertionManager.ElementTextEquals(rq03pages._notFoundMessage, "There was no result for your search.");
                        break;
                    case "Brief description":
                        Assert.AreEqual(searchData, searchtermresult, "The search term result displayed is incorrect");
                        AssertionManager.ElementTextEquals(rq03pages._notFoundMessage, "There was no result for your search.");
                        break;
                    case "Keyword":
                        Assert.AreEqual(searchData, searchtermresult, "The search term result displayed is incorrect");
                        AssertionManager.ElementTextEquals(rq03pages._notFoundMessage, "There was no result for your search.");
                        break;
                    case "Title":

                        Assert.AreEqual(searchData, searchtermresult, "The search term result displayed is incorrect");
                        AssertionManager.ElementTextEquals(rq03pages._notFoundMessage, "There was no result for your search.");
                        break;
                }
            }

        [When(@"user navigate to the browser catalog tab to perform the search without Saving")]
        public void WhenUserNavigateToTheBrowserCatalogTabToPerformTheSearchWithoutSaving()
        {
            rq03pages = new RQ03_Pages(rq04_Driver);
            rq04_Driver.SwitchTo().DefaultContent();
            rq03pages._browseCatalogTab.Click();
        }

        [Then(@"system should not display the IsEnable unchecked items in the searchBox list")]
        public void ThenSystemShouldNotDisplayTheIsEnableUncheckedItemsInTheSearchBoxList()
        {
            {
                // rq04pages = new RQ04_Pages(rq04_Driver);
                Thread.Sleep(5000);
                IList<IWebElement> lstWebElement = rq04_Driver.FindElements(By.XPath("//li[@class='ui-menu-item']/a[@class='ui-corner-all']"));

                if (lstWebElement.Count != 0)
                {
                    /*foreach (IWebElement element in lstWebElement)
                    {
                        Console.WriteLine(element.Text);
                        if (element.Text == RQ05_Pages.selectedTitleText)
                        {
                            throw new Exception(string.Format("IsEnable uncheck items displaying in the search list"));
                        }
                    }*/
                    throw new Exception(string.Format("Auto Search Suggestions are displayed, When IsEnable check box is unchecked OR items is Archived"));
                }
            }
        }

        [Then(@"system should display the search result for the selected search suggestion option")]
        public void ThenSystemShouldDisplayTheSearchResultForTheSelectedSearchSuggestionOption()
        {
            rq03pages = new RQ03_Pages(rq04_Driver);
            rq06pages = new RQ06_Pages(rq04_Driver);
            
            string resultData = rq03pages._displaySearchResult.Text.Replace('"', ' ').Trim();
            // string resultData = rq03pages._displaySearchResult.Text;
            // rq03pages._displaySearchResult.Text
            if (RQ06_StepDefinitions.selectFromList == resultData)
            {
                Console.WriteLine("Select list item matched from displayed data");
            }
            else
            {
                throw new Exception(string.Format("Select list item not matched from displayed data"));
            }
        }

        [Then(@"system should display the search suggestions of ""([^""]*)"" items only\(related to the selected search term\)")]
        public void ThenSystemShouldDisplayTheSearchSuggestionsOfItemsOnlyRelatedToTheSelectedSearchTerm(string catalogType)
        {
            rq04pages = new RQ04_Pages(rq04_Driver);
            rq03pages = new RQ03_Pages(rq04_Driver);
            Thread.Sleep(5000);
            IList<string> arrListItems = new List<string>();
            IList<string> sqlSearchKeywordList = new List<string>();
            IList<int> sqlclassificationSortList = new List<int>();
            int p = 0;

            // IList<IWebElement> lstWebElement = rq04_Driver.FindElements(By.XPath("//li[@class='ui-menu-item']/a[@class='ui-corner-all']"));
            IList<IWebElement> lstWebElement = rq04_Driver.FindElements(By.XPath("//ul[@role='listbox']//a"));
            if (lstWebElement.Count > 0)
            {
                foreach (IWebElement element in lstWebElement)
                {
                    Console.WriteLine(element.Text);
                    arrListItems.Add(element.Text);
                }
            }
            else
            {
                throw new Exception(string.Format("Auto Search Suggestions are not displayed"));
            }
            Thread.Sleep(5000);
            string inputData = rq03pages._textBoxInputMainSearchCatalog.Text;
            string inputData1 = rq04_Driver.FindElement(By.XPath("//div[@id='topsearchbar']")).Text;
            string inputData2 = rq04_Driver.FindElement(By.Id("searchCatalog")).Text;

            if(catalogType == "preferred")
            {
                query = "SELECT Distinct WP.PackageID, WP.CatID, WP.Deleted, WP.MemberOfGroup, WP.VisibleGroup, WP.LicenseDisable,\r\nISNULL(wpl.Title, WP.PackageTitle) AS PackageTitle, cclass.ClassificationName, cclass.ClassificationType,\r\nccm.ShowAlert, cclass.ImagePath AS ClassificationImagePath, case when cclass.ClassificationType = 0\r\nthen 0 when  cclass.ClassificationType = 1 then 2 else 1 end as ClassificationSort,\r\nISNULL(wpl.Description, WP.PackageDesc) AS PackageDesc, \r\nISNULL(wpl.BriefDescription, WP.BriefDescription) AS BriefDescription, WP.PackageVisible, WP.PackageRequest,\r\nWP.RunTime, WP.Reboots, WP.AppMethod, WP.OUInherit, WP.PackageRating, WP.PackageRank,  WP.vOUInherit,\r\nWP.GroupInherit, WP.ImagePath, WP.Type, WP.HasAlternate, WP.LicenseID_FK,l.PendingInstalls,\r\nl.LicenseCount - l.LicenseUsed AS LicenseRemaining, WP.Resource, WP.Site,   l.LicenseCount,\r\nl.LicenseUsed, l.Scope, l.Enforce, WP.ShowInventoryData, WP.AllowRental, WP.MaxRentalTime,\r\nWP.DisablePermanent, WP.AllowROB, WP.AllowRTP,  WP.AllowRTM, WP.AllowManual, WP.AllowUninstall,\r\nWP.AllowRepair, WP.VisibleShowMessage,WP.VisibleMessage, WP.ShowInventoryCostData,\r\n(Case WP.UseInventoryCost WHEN 0 Then ISNULL(WP.CatalogCost, 0) Else ISNULL(l.LicenseCost, 0) END) AS LicenseCost,\r\nWP.OSDRoleID, WP.TemplateID_FK, WP.AllowCollectionDeployment,wp.EnableScheduling,wp.AllowFileUpload,\r\nWP.EnableAlert, (Case ISNULL(WP.CheckFNMPLicensePosition, 0) WHEN 0 Then NULL Else WP.FUID END) AS FUID,\r\nWP.CheckFNMPAdvancedLicense, WP.FnmpLicenseScope, WP.CreatedOn, WP.UpdatedOn,\r\nWP.LinkPackageID_FK AS LinkedPackageID, ISNULL(DisableAppDetection,0) AS DisableAppDetection,\r\n(SELECT STUFF((SELECT ',' + CONVERT(NVARCHAR, PC.CategoryID) + '=' + CONVERT(NVARCHAR,\r\nISNULL(C.Secured, 0)) FROM WD_Package_Category PC INNER JOIN WD_Category C ON PC.CategoryID = C.CatID\r\nWHERE PC.PackageID = WP.PackageID FOR XML PATH('')), 1, 1, '')) AS Categories,\r\n(SELECT STUFF((SELECT '||' + VPP.PropertyName + ',' + VPP.PropertyValue + ',' + CONVERT(NVARCHAR, VPP.Visible) + ',' + VPP.Operator\r\nFROM dbo.WD_PackageProperty VPP WHERE VPP.PackageID_FK = WP.PackageID\r\nORDER BY VPP.Visible ASC FOR XML PATH('') ), 1, 2, '')) AS PackageProperties,\r\n(SELECT STUFF((SELECT '||' + VPP.PropertyName + ',' + VPP.PropertyValue + ',' + CONVERT(NVARCHAR, VPP.Visible) + ',' + VPP.Operator FROM dbo.WD_VPackageProperty VPP\r\nWHERE VPP.PackageID_FK = WP.PackageID ORDER BY VPP.Visible ASC FOR XML PATH('') ), 1, 2, '')) AS PackageVisibilities\r\nFROM WD_WebPackageLanguage AS wpl RIGHT OUTER JOIN    dbo.WD_WebPackages AS WP ON wpl.PackageID = WP.PackageID AND wpl.LanguageID = 0  LEFT OUTER JOIN  WD_License AS l ON WP.LicenseID_FK = l.LicenseID  left outer JOIN    dbo.WD_CatalogClassificationMapping AS ccm ON WP.PackageID = ccm.CatalogID  left outer join    dbo.WD_CatalogClassification As cclass on ccm.ClassificationID = cclass.ID\r\nWHERE  WP.Deleted IN (0, 1)  AND WP.PackageID Not IN ( Select Distinct PM.PackageID from WD_PackageMapper PM Where PM.MapperType in (2,3,4) )   AND WP.Type Not in (19,20,21,22,23) AND WP.PackageID Not IN (select Distinct packageID_fk from wd_Package_Deployment\r\nwhere PackageType In (19,20,21,22,23)) AND PackageVisible=1 AND PackageTitle like '%"+ cc.getDataFromFile("ip_rq04_preferred") + "%'\r\norder by ClassificationSort,PackageTitle";
            }
            else if (catalogType == "nonClassifed")
            {
                query = "SELECT Distinct WP.PackageID, WP.CatID, WP.Deleted, WP.MemberOfGroup, WP.VisibleGroup, WP.LicenseDisable,\r\nISNULL(wpl.Title, WP.PackageTitle) AS PackageTitle, cclass.ClassificationName, cclass.ClassificationType,\r\nccm.ShowAlert, cclass.ImagePath AS ClassificationImagePath, case when cclass.ClassificationType = 0\r\nthen 0 when  cclass.ClassificationType = 1 then 2 else 1 end as ClassificationSort,\r\nISNULL(wpl.Description, WP.PackageDesc) AS PackageDesc, \r\nISNULL(wpl.BriefDescription, WP.BriefDescription) AS BriefDescription, WP.PackageVisible, WP.PackageRequest,\r\nWP.RunTime, WP.Reboots, WP.AppMethod, WP.OUInherit, WP.PackageRating, WP.PackageRank,  WP.vOUInherit,\r\nWP.GroupInherit, WP.ImagePath, WP.Type, WP.HasAlternate, WP.LicenseID_FK,l.PendingInstalls,\r\nl.LicenseCount - l.LicenseUsed AS LicenseRemaining, WP.Resource, WP.Site,   l.LicenseCount,\r\nl.LicenseUsed, l.Scope, l.Enforce, WP.ShowInventoryData, WP.AllowRental, WP.MaxRentalTime,\r\nWP.DisablePermanent, WP.AllowROB, WP.AllowRTP,  WP.AllowRTM, WP.AllowManual, WP.AllowUninstall,\r\nWP.AllowRepair, WP.VisibleShowMessage,WP.VisibleMessage, WP.ShowInventoryCostData,\r\n(Case WP.UseInventoryCost WHEN 0 Then ISNULL(WP.CatalogCost, 0) Else ISNULL(l.LicenseCost, 0) END) AS LicenseCost,\r\nWP.OSDRoleID, WP.TemplateID_FK, WP.AllowCollectionDeployment,wp.EnableScheduling,wp.AllowFileUpload,\r\nWP.EnableAlert, (Case ISNULL(WP.CheckFNMPLicensePosition, 0) WHEN 0 Then NULL Else WP.FUID END) AS FUID,\r\nWP.CheckFNMPAdvancedLicense, WP.FnmpLicenseScope, WP.CreatedOn, WP.UpdatedOn,\r\nWP.LinkPackageID_FK AS LinkedPackageID, ISNULL(DisableAppDetection,0) AS DisableAppDetection,\r\n(SELECT STUFF((SELECT ',' + CONVERT(NVARCHAR, PC.CategoryID) + '=' + CONVERT(NVARCHAR,\r\nISNULL(C.Secured, 0)) FROM WD_Package_Category PC INNER JOIN WD_Category C ON PC.CategoryID = C.CatID\r\nWHERE PC.PackageID = WP.PackageID FOR XML PATH('')), 1, 1, '')) AS Categories,\r\n(SELECT STUFF((SELECT '||' + VPP.PropertyName + ',' + VPP.PropertyValue + ',' + CONVERT(NVARCHAR, VPP.Visible) + ',' + VPP.Operator\r\nFROM dbo.WD_PackageProperty VPP WHERE VPP.PackageID_FK = WP.PackageID\r\nORDER BY VPP.Visible ASC FOR XML PATH('') ), 1, 2, '')) AS PackageProperties,\r\n(SELECT STUFF((SELECT '||' + VPP.PropertyName + ',' + VPP.PropertyValue + ',' + CONVERT(NVARCHAR, VPP.Visible) + ',' + VPP.Operator FROM dbo.WD_VPackageProperty VPP\r\nWHERE VPP.PackageID_FK = WP.PackageID ORDER BY VPP.Visible ASC FOR XML PATH('') ), 1, 2, '')) AS PackageVisibilities\r\nFROM WD_WebPackageLanguage AS wpl RIGHT OUTER JOIN    dbo.WD_WebPackages AS WP ON wpl.PackageID = WP.PackageID AND wpl.LanguageID = 0  LEFT OUTER JOIN  WD_License AS l ON WP.LicenseID_FK = l.LicenseID  left outer JOIN    dbo.WD_CatalogClassificationMapping AS ccm ON WP.PackageID = ccm.CatalogID  left outer join    dbo.WD_CatalogClassification As cclass on ccm.ClassificationID = cclass.ID\r\nWHERE  WP.Deleted IN (0, 1)  AND WP.PackageID Not IN ( Select Distinct PM.PackageID from WD_PackageMapper PM Where PM.MapperType in (2,3,4) )   AND WP.Type Not in (19,20,21,22,23) AND WP.PackageID Not IN (select Distinct packageID_fk from wd_Package_Deployment\r\nwhere PackageType In (19,20,21,22,23)) AND PackageVisible=1 AND PackageTitle like '%" + cc.getDataFromFile("ip_rq04__nonClassified") +  "%'\r\norder by ClassificationSort,PackageTitle";
            }
            else if (catalogType == "nonPreferred")
            {
                query = "SELECT Distinct WP.PackageID, WP.CatID, WP.Deleted, WP.MemberOfGroup, WP.VisibleGroup, WP.LicenseDisable,\r\nISNULL(wpl.Title, WP.PackageTitle) AS PackageTitle, cclass.ClassificationName, cclass.ClassificationType,\r\nccm.ShowAlert, cclass.ImagePath AS ClassificationImagePath, case when cclass.ClassificationType = 0\r\nthen 0 when  cclass.ClassificationType = 1 then 2 else 1 end as ClassificationSort,\r\nISNULL(wpl.Description, WP.PackageDesc) AS PackageDesc, \r\nISNULL(wpl.BriefDescription, WP.BriefDescription) AS BriefDescription, WP.PackageVisible, WP.PackageRequest,\r\nWP.RunTime, WP.Reboots, WP.AppMethod, WP.OUInherit, WP.PackageRating, WP.PackageRank,  WP.vOUInherit,\r\nWP.GroupInherit, WP.ImagePath, WP.Type, WP.HasAlternate, WP.LicenseID_FK,l.PendingInstalls,\r\nl.LicenseCount - l.LicenseUsed AS LicenseRemaining, WP.Resource, WP.Site,   l.LicenseCount,\r\nl.LicenseUsed, l.Scope, l.Enforce, WP.ShowInventoryData, WP.AllowRental, WP.MaxRentalTime,\r\nWP.DisablePermanent, WP.AllowROB, WP.AllowRTP,  WP.AllowRTM, WP.AllowManual, WP.AllowUninstall,\r\nWP.AllowRepair, WP.VisibleShowMessage,WP.VisibleMessage, WP.ShowInventoryCostData,\r\n(Case WP.UseInventoryCost WHEN 0 Then ISNULL(WP.CatalogCost, 0) Else ISNULL(l.LicenseCost, 0) END) AS LicenseCost,\r\nWP.OSDRoleID, WP.TemplateID_FK, WP.AllowCollectionDeployment,wp.EnableScheduling,wp.AllowFileUpload,\r\nWP.EnableAlert, (Case ISNULL(WP.CheckFNMPLicensePosition, 0) WHEN 0 Then NULL Else WP.FUID END) AS FUID,\r\nWP.CheckFNMPAdvancedLicense, WP.FnmpLicenseScope, WP.CreatedOn, WP.UpdatedOn,\r\nWP.LinkPackageID_FK AS LinkedPackageID, ISNULL(DisableAppDetection,0) AS DisableAppDetection,\r\n(SELECT STUFF((SELECT ',' + CONVERT(NVARCHAR, PC.CategoryID) + '=' + CONVERT(NVARCHAR,\r\nISNULL(C.Secured, 0)) FROM WD_Package_Category PC INNER JOIN WD_Category C ON PC.CategoryID = C.CatID\r\nWHERE PC.PackageID = WP.PackageID FOR XML PATH('')), 1, 1, '')) AS Categories,\r\n(SELECT STUFF((SELECT '||' + VPP.PropertyName + ',' + VPP.PropertyValue + ',' + CONVERT(NVARCHAR, VPP.Visible) + ',' + VPP.Operator\r\nFROM dbo.WD_PackageProperty VPP WHERE VPP.PackageID_FK = WP.PackageID\r\nORDER BY VPP.Visible ASC FOR XML PATH('') ), 1, 2, '')) AS PackageProperties,\r\n(SELECT STUFF((SELECT '||' + VPP.PropertyName + ',' + VPP.PropertyValue + ',' + CONVERT(NVARCHAR, VPP.Visible) + ',' + VPP.Operator FROM dbo.WD_VPackageProperty VPP\r\nWHERE VPP.PackageID_FK = WP.PackageID ORDER BY VPP.Visible ASC FOR XML PATH('') ), 1, 2, '')) AS PackageVisibilities\r\nFROM WD_WebPackageLanguage AS wpl RIGHT OUTER JOIN    dbo.WD_WebPackages AS WP ON wpl.PackageID = WP.PackageID AND wpl.LanguageID = 0  LEFT OUTER JOIN  WD_License AS l ON WP.LicenseID_FK = l.LicenseID  left outer JOIN    dbo.WD_CatalogClassificationMapping AS ccm ON WP.PackageID = ccm.CatalogID  left outer join    dbo.WD_CatalogClassification As cclass on ccm.ClassificationID = cclass.ID\r\nWHERE  WP.Deleted IN (0, 1)  AND WP.PackageID Not IN ( Select Distinct PM.PackageID from WD_PackageMapper PM Where PM.MapperType in (2,3,4) )   AND WP.Type Not in (19,20,21,22,23) AND WP.PackageID Not IN (select Distinct packageID_fk from wd_Package_Deployment\r\nwhere PackageType In (19,20,21,22,23)) AND PackageVisible=1 AND PackageTitle like '%"+ cc.getDataFromFile("ip_rq04_nonPreferred") + "%'\r\norder by ClassificationSort,PackageTitle";
            }

            // string query = "SELECT Distinct WP.PackageID, WP.CatID, WP.Deleted, WP.MemberOfGroup, WP.VisibleGroup, WP.LicenseDisable,\r\nISNULL(wpl.Title, WP.PackageTitle) AS PackageTitle, cclass.ClassificationName, cclass.ClassificationType,\r\nccm.ShowAlert, cclass.ImagePath AS ClassificationImagePath, case when cclass.ClassificationType = 0\r\nthen 0 when  cclass.ClassificationType = 1 then 2 else 1 end as ClassificationSort,\r\nISNULL(wpl.Description, WP.PackageDesc) AS PackageDesc, \r\nISNULL(wpl.BriefDescription, WP.BriefDescription) AS BriefDescription, WP.PackageVisible, WP.PackageRequest,\r\nWP.RunTime, WP.Reboots, WP.AppMethod, WP.OUInherit, WP.PackageRating, WP.PackageRank,  WP.vOUInherit,\r\nWP.GroupInherit, WP.ImagePath, WP.Type, WP.HasAlternate, WP.LicenseID_FK,l.PendingInstalls,\r\nl.LicenseCount - l.LicenseUsed AS LicenseRemaining, WP.Resource, WP.Site,   l.LicenseCount,\r\nl.LicenseUsed, l.Scope, l.Enforce, WP.ShowInventoryData, WP.AllowRental, WP.MaxRentalTime,\r\nWP.DisablePermanent, WP.AllowROB, WP.AllowRTP,  WP.AllowRTM, WP.AllowManual, WP.AllowUninstall,\r\nWP.AllowRepair, WP.VisibleShowMessage,WP.VisibleMessage, WP.ShowInventoryCostData,\r\n(Case WP.UseInventoryCost WHEN 0 Then ISNULL(WP.CatalogCost, 0) Else ISNULL(l.LicenseCost, 0) END) AS LicenseCost,\r\nWP.OSDRoleID, WP.TemplateID_FK, WP.AllowCollectionDeployment,wp.EnableScheduling,wp.AllowFileUpload,\r\nWP.EnableAlert, (Case ISNULL(WP.CheckFNMPLicensePosition, 0) WHEN 0 Then NULL Else WP.FUID END) AS FUID,\r\nWP.CheckFNMPAdvancedLicense, WP.FnmpLicenseScope, WP.CreatedOn, WP.UpdatedOn,\r\nWP.LinkPackageID_FK AS LinkedPackageID, ISNULL(DisableAppDetection,0) AS DisableAppDetection,\r\n(SELECT STUFF((SELECT ',' + CONVERT(NVARCHAR, PC.CategoryID) + '=' + CONVERT(NVARCHAR,\r\nISNULL(C.Secured, 0)) FROM WD_Package_Category PC INNER JOIN WD_Category C ON PC.CategoryID = C.CatID\r\nWHERE PC.PackageID = WP.PackageID FOR XML PATH('')), 1, 1, '')) AS Categories,\r\n(SELECT STUFF((SELECT '||' + VPP.PropertyName + ',' + VPP.PropertyValue + ',' + CONVERT(NVARCHAR, VPP.Visible) + ',' + VPP.Operator\r\nFROM dbo.WD_PackageProperty VPP WHERE VPP.PackageID_FK = WP.PackageID\r\nORDER BY VPP.Visible ASC FOR XML PATH('') ), 1, 2, '')) AS PackageProperties,\r\n(SELECT STUFF((SELECT '||' + VPP.PropertyName + ',' + VPP.PropertyValue + ',' + CONVERT(NVARCHAR, VPP.Visible) + ',' + VPP.Operator FROM dbo.WD_VPackageProperty VPP\r\nWHERE VPP.PackageID_FK = WP.PackageID ORDER BY VPP.Visible ASC FOR XML PATH('') ), 1, 2, '')) AS PackageVisibilities\r\nFROM WD_WebPackageLanguage AS wpl RIGHT OUTER JOIN    dbo.WD_WebPackages AS WP ON wpl.PackageID = WP.PackageID AND wpl.LanguageID = 0  LEFT OUTER JOIN  WD_License AS l ON WP.LicenseID_FK = l.LicenseID  left outer JOIN    dbo.WD_CatalogClassificationMapping AS ccm ON WP.PackageID = ccm.CatalogID  left outer join    dbo.WD_CatalogClassification As cclass on ccm.ClassificationID = cclass.ID\r\nWHERE  WP.Deleted IN (0, 1)  AND WP.PackageID Not IN ( Select Distinct PM.PackageID from WD_PackageMapper PM Where PM.MapperType in (2,3,4) )   AND WP.Type Not in (19,20,21,22,23) AND WP.PackageID Not IN (select Distinct packageID_fk from wd_Package_Deployment\r\nwhere PackageType In (19,20,21,22,23)) AND PackageVisible=1 AND PackageTitle like '%" + inputData + "%'\r\norder by ClassificationSort,PackageTitle";
            

            // string quer1 = "SELECT Distinct WP.PackageID, WP.CatID, WP.Deleted, WP.MemberOfGroup, WP.VisibleGroup, WP.LicenseDisable,\r\nISNULL(wpl.Title, WP.PackageTitle) AS PackageTitle, cclass.ClassificationName, cclass.ClassificationType,\r\nccm.ShowAlert, cclass.ImagePath AS ClassificationImagePath, case when cclass.ClassificationType = 0\r\nthen 0 when  cclass.ClassificationType = 1 then 2 else 1 end as ClassificationSort,\r\nISNULL(wpl.Description, WP.PackageDesc) AS PackageDesc, \r\nISNULL(wpl.BriefDescription, WP.BriefDescription) AS BriefDescription, WP.PackageVisible, WP.PackageRequest,\r\nWP.RunTime, WP.Reboots, WP.AppMethod, WP.OUInherit, WP.PackageRating, WP.PackageRank,  WP.vOUInherit,\r\nWP.GroupInherit, WP.ImagePath, WP.Type, WP.HasAlternate, WP.LicenseID_FK,l.PendingInstalls,\r\nl.LicenseCount - l.LicenseUsed AS LicenseRemaining, WP.Resource, WP.Site,   l.LicenseCount,\r\nl.LicenseUsed, l.Scope, l.Enforce, WP.ShowInventoryData, WP.AllowRental, WP.MaxRentalTime,\r\nWP.DisablePermanent, WP.AllowROB, WP.AllowRTP,  WP.AllowRTM, WP.AllowManual, WP.AllowUninstall,\r\nWP.AllowRepair, WP.VisibleShowMessage,WP.VisibleMessage, WP.ShowInventoryCostData,\r\n(Case WP.UseInventoryCost WHEN 0 Then ISNULL(WP.CatalogCost, 0) Else ISNULL(l.LicenseCost, 0) END) AS LicenseCost,\r\nWP.OSDRoleID, WP.TemplateID_FK, WP.AllowCollectionDeployment,wp.EnableScheduling,wp.AllowFileUpload,\r\nWP.EnableAlert, (Case ISNULL(WP.CheckFNMPLicensePosition, 0) WHEN 0 Then NULL Else WP.FUID END) AS FUID,\r\nWP.CheckFNMPAdvancedLicense, WP.FnmpLicenseScope, WP.CreatedOn, WP.UpdatedOn,\r\nWP.LinkPackageID_FK AS LinkedPackageID, ISNULL(DisableAppDetection,0) AS DisableAppDetection,\r\n(SELECT STUFF((SELECT ',' + CONVERT(NVARCHAR, PC.CategoryID) + '=' + CONVERT(NVARCHAR,\r\nISNULL(C.Secured, 0)) FROM WD_Package_Category PC INNER JOIN WD_Category C ON PC.CategoryID = C.CatID\r\nWHERE PC.PackageID = WP.PackageID FOR XML PATH('')), 1, 1, '')) AS Categories,\r\n(SELECT STUFF((SELECT '||' + VPP.PropertyName + ',' + VPP.PropertyValue + ',' + CONVERT(NVARCHAR, VPP.Visible) + ',' + VPP.Operator\r\nFROM dbo.WD_PackageProperty VPP WHERE VPP.PackageID_FK = WP.PackageID\r\nORDER BY VPP.Visible ASC FOR XML PATH('') ), 1, 2, '')) AS PackageProperties,\r\n(SELECT STUFF((SELECT '||' + VPP.PropertyName + ',' + VPP.PropertyValue + ',' + CONVERT(NVARCHAR, VPP.Visible) + ',' + VPP.Operator FROM dbo.WD_VPackageProperty VPP\r\nWHERE VPP.PackageID_FK = WP.PackageID ORDER BY VPP.Visible ASC FOR XML PATH('') ), 1, 2, '')) AS PackageVisibilities\r\nFROM WD_WebPackageLanguage AS wpl RIGHT OUTER JOIN    dbo.WD_WebPackages AS WP ON wpl.PackageID = WP.PackageID AND wpl.LanguageID = 0  LEFT OUTER JOIN  WD_License AS l ON WP.LicenseID_FK = l.LicenseID  left outer JOIN    dbo.WD_CatalogClassificationMapping AS ccm ON WP.PackageID = ccm.CatalogID  left outer join    dbo.WD_CatalogClassification As cclass on ccm.ClassificationID = cclass.ID\r\nWHERE  WP.Deleted IN (0, 1)  AND WP.PackageID Not IN ( Select Distinct PM.PackageID from WD_PackageMapper PM Where PM.MapperType in (2,3,4) )   AND WP.Type Not in (19,20,21,22,23) AND WP.PackageID Not IN (select Distinct packageID_fk from wd_Package_Deployment\r\nwhere PackageType In (19,20,21,22,23)) AND PackageVisible=1 AND PackageTitle like '%Box%'\r\norder by ClassificationSort, PackageTitle";

            SqlDataReader reader = HooksSpecFlow.connectAppPortal.ExecuteReader(CommandType.Text, query);

            while (reader.Read())
            {
                if (p <= arrListItems.Count)
                {
                    string searchKeywordValue = reader["PackageTitle"].ToString();
                    sqlSearchKeywordList.Add(searchKeywordValue);

                    int classificationSort = (int)reader["ClassificationSort"];
                    sqlclassificationSortList.Add(classificationSort);
                }
            }

            
            for(int j=0; j< arrListItems.Count; j++)
            {
                if (sqlclassificationSortList[j] >= max)
                {
                    Console.WriteLine("All items are preferred items");
                    max = sqlclassificationSortList[j];

                }
                else
                {
                    throw new Exception(string.Format("List consist of multiple catalog classifications"));
                }
            }

            // sqlSearchKeywordList = sqlSearchKeywordList.OrderBy(x => x.ToString()).ToList();

            for (int i = 0; i < arrListItems.Count; i++)
            {
                if (sqlSearchKeywordList[i].ToLower() != arrListItems[i].ToLower())
                {
                    throw new Exception(string.Format("List of Items not matched"));
                }
            }
            Thread.Sleep(2000);
            reader.Close();
        }

        [When(@"user click on the visibility button")]
        public void WhenUserClickOnTheVisibilityButton()
        {
            rq04pages = new RQ04_Pages(rq04_Driver);
            rq04pages._btnVisibility.Click();
        }

        [When(@"ensure that visibility is provided for the user")]
        public void WhenEnsureThatVisibilityIsProvidedForTheUser()
        {
            rq04pages = new RQ04_Pages(rq04_Driver);
            rq04pages.VerifyUserAbleToSelectTheCity();
        }

        [Given(@"nonAdmin user(.*) is logged into the app portal")]
        public void GivenNonAdminUserIsLoggedIntoTheAppPortal(int p0)
        {
            InputSimulator inputSim = new InputSimulator();
            
            if (cc.getDataFromFile("browser") == "chrome")
            {
                new WebDriverManager.DriverManager().SetUpDriver(new ChromeConfig());
                rq04_Driver = new ChromeDriver();
            }
            else if (cc.getDataFromFile("browser") == "edge")
            {
                new WebDriverManager.DriverManager().SetUpDriver(new EdgeConfig());
                rq04_Driver = new EdgeDriver();
            }
            else if (cc.getDataFromFile("browser") == "firefox")
            {
                new WebDriverManager.DriverManager().SetUpDriver(new FirefoxConfig());
                rq04_Driver = new FirefoxDriver();
            }
            else
            {
                Console.WriteLine("Not a valid browser name");
            }

            rq04_Driver.Manage().Window.Maximize();
            rq04_Driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
            rq04_Driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(30);
            clearCacheAndCookies();
            // rq04_Driver.Navigate().GoToUrl("chrome://settings/clearBrowserData");
            //_container.RegisterInstanceAs<IWebDriver>(driver);

            // Login Code

            Thread.Sleep(3000);

            // driver.Navigate().GoToUrl("http://10.75.204.205/esd");

            // Testing URL
            String launchingURL = cc.getDataFromFile("url");
            // driver.Navigate().GoToUrl("http://10.75.205.122/esd/");
            rq04_Driver.Navigate().GoToUrl(launchingURL);

            Thread.Sleep(3000);

            // Enter username
            String uname = cc.getDataFromFile("nonadminusernamepune");
            inputSim.Keyboard.TextEntry(uname);
            Thread.Sleep(1000);
            // press Tab key 
            inputSim.Keyboard.KeyPress(VirtualKeyCode.TAB);
            Thread.Sleep(1000);
            // Enter Password
            String passwd = cc.getDataFromFile("pass");
            inputSim.Keyboard.TextEntry(passwd);
            Thread.Sleep(6000);


            inputSim.Keyboard.KeyPress(VirtualKeyCode.TAB);
            inputSim.Keyboard.KeyPress(VirtualKeyCode.RETURN);
            Thread.Sleep(18000);
            Assert.True(rq04_Driver.Title.Contains("Flexera Software App Portal"));

            Console.WriteLine("Authentication Pop-up Login Completed through hooks");
        }

        public void clearCacheAndCookies()
        {
            rq04_Driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            rq04_Driver.Navigate().GoToUrl("chrome://settings/clearBrowserData");

            IWebElement root1 = rq04_Driver.FindElement(By.CssSelector("settings-ui"));
            IWebElement shadowRoot1 = expandRootElement(root1);
            IWebElement root2 = shadowRoot1.FindElement(By.CssSelector("settings-main"));
            IWebElement shadowRoot2 = expandRootElement(root2);
            IWebElement root3 = shadowRoot2.FindElement(By.CssSelector("settings-basic-page"));
            IWebElement shadowRoot3 = expandRootElement(root3);
            IWebElement root4 = shadowRoot3.FindElement(By.CssSelector("settings-section > settings-privacy-page"));
            IWebElement shadowRoot4 = expandRootElement(root4);
            IWebElement root5 = shadowRoot4.FindElement(By.CssSelector("settings-clear-browsing-data-dialog"));
            IWebElement shadowRoot5 = expandRootElement(root5);
            IWebElement root6 = shadowRoot5.FindElement(By.CssSelector("#clearBrowsingDataDialog"));
            IWebElement root7 = root6.FindElement(By.CssSelector("cr-tabs[role='tablist']"));

            root7.Click();

            IWebElement clearDataButton = root6.FindElement(By.CssSelector("#clearBrowsingDataConfirm"));

            clearDataButton.Click();
        }

        public IWebElement expandRootElement(IWebElement element)
        {
            //var shadowHost = rq04_Driver.FindElement(By.CssSelector("#shadow_host"));
            var js = ((IJavaScriptExecutor)rq04_Driver);
            return (IWebElement)js.ExecuteScript("return arguments[0].shadowRoot", element);
            /*var shadowRoot = (IWebElement)js.ExecuteScript("return arguments[0].shadowRoot", shadowHost);
            var shadowContent = shadowRoot.FindElement(By.CssSelector("#shadow_content"));
            return (IWebElement)((IJavaScriptExecutor)rq04_Driver).ExecuteScript("return arguments[0].shadowRoot", element);*/
        }
    }
}
