﻿using NUnit.Framework;
using OpenQA.Selenium;
using RazorEngine.Compilation.ImpromptuInterface;
using SpecFlowBDD_22.Pages;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WindowsInput;
using WindowsInput.Native;
using SpecFlowBDD_22.HooksManager;
using SpecFlowBDD_22.Framework;

namespace SpecFlowBDD_22.StepDefinitions
{
    [Binding]
    public class RQ05_StepDefinitions
    {
        public IWebDriver rq05_Driver;

        public RQ05_StepDefinitions(IWebDriver rDriver)
        {
            this.rq05_Driver = rDriver;
            //PageFactory.
        }

        RQ05_Pages rq05pages;
        RQ03_Pages rq03pages;

        [Then(@"system should display the search results based on Preferred,Non-Classified,Non-preferred catalog items order")]
        public void ThenSystemShouldDisplayTheSearchResultsBasedOnPreferredNon_ClassifiedNon_PreferredCatalogItemsOrder()
        {
            rq05pages = new RQ05_Pages(rq05_Driver);
            rq05pages.VerifyTheSearchResultBasedOnPreferredNonClassifiedNonpreferred();
        }

        /*[Then(@"system should display the search results based on ""([^""]*)"" catalog items order")]
        public void ThenSystemShouldDisplayTheSearchResultsBasedOnCatalogItemsOrder(string catalogClassification)
        {
            rq05pages = new RQ05_Pages(rq05_Driver);
            rq05pages.VerifyTheSearchResultBasedOnPreferredNonClassifiedNonpreferredParameter(catalogClassification);
        }*/


        [Then(@"all the Preferred,Non-classified,Non-preferred catalog items catalog items should be sorted alphabetically in respective classifications")]
        public void ThenAllThePreferredNon_ClassifiedNon_PreferredCatalogItemsCatalogItemsShouldBeSortedAlphabeticallyInRespectiveClassifications()
        {
            rq05pages = new RQ05_Pages(rq05_Driver);
            rq05pages.VerifyAllThePreferredNon_ClassifiedNon_PreferredCatalogItemsCatalogItemsShouldBeSortedAlphabeticallyInRespectiveClassifications();
        }
        // Scenario-5

        [When(@"user navigate to the catalog item page\(Admin >> Catalog Management >> Current Catalog Items >>View All Item >> Double Click on any items >> A new window\(pop-up\) will open >>In Global\(Tab\) >> Inside Global Options box\) to disable the items")]
        public void WhenUserNavigateToTheCatalogItemPageAdminCatalogManagementCurrentCatalogItemsViewAllItemDoubleClickOnAnyItemsANewWindowPop_UpWillOpenInGlobalTabInsideGlobalOptionsBoxToDisableTheItems()
        {
            rq05pages = new RQ05_Pages(rq05_Driver);
            rq05pages.UserNavigateToTheCatalogItemPageAdminCatalogManagementCurrentCatalogItemsViewAllItemDoubleClickOnAnyItems();
        }

        [When(@"user navigate to the catalog item page\(Admin >> Catalog Management >> Current Catalog Items >>View All Item >> Double Click on any items >> A new window\(pop-up\) will open >>In Global\(Tab\) >> Inside Global Options box\) to disable the items\(Archive")]
        public void WhenUserNavigateToTheCatalogItemPageAdminCatalogManagementCurrentCatalogItemsViewAllItemDoubleClickOnAnyItemsANewWindowPop_UpWillOpenInGlobalTabInsideGlobalOptionsBoxToDisableTheItemsArchive()
        {
            rq05pages = new RQ05_Pages(rq05_Driver);
            rq05pages.UserNavigateToTheCatalogItemPageAdminCatalogManagementCurrentCatalogItemsViewAllItemDoubleClickOnAnyItemsArchive();
        }


        [Then(@"user click on Save button and display the message")]
        public void ThenUserClickOnSaveButtonAndDisplayTheMessage()
        {
            rq03pages = new RQ03_Pages(rq05_Driver);
            rq03pages.SaveAndVerify();
        }

        [When(@"user uncheck the Is enabled check box")]
        public void WhenUserUncheckTheIsEnabledCheckBox()
        {
            rq05pages = new RQ05_Pages(rq05_Driver);
            if (rq05pages._chkBoxIsEnabled.Selected)
            {
                rq05pages._chkBoxIsEnabled.Click();
            }
        }

        [When(@"user check the Is enabled check box")]
        public void WhenUserCheckTheIsEnabledCheckBox()
        {
            rq05pages = new RQ05_Pages(rq05_Driver);
            if (!rq05pages._chkBoxIsEnabled.Selected)
            {
                rq05pages._chkBoxIsEnabled.Click();
            }
        }


        [When(@"click on Save button and verify the message")]
        public void WhenClickOnSaveButtonAndVerifyTheMessage()
        {
            rq05pages = new RQ05_Pages(rq05_Driver);
            rq05pages._saveButton.Click();
            if (!rq05pages._saveMessagae.Displayed)
            {
                throw new Exception(string.Format("Saved message is not displayed"));
            }
        }

        [Then(@"Is enabled check box should display as unchecked")]
        public void ThenIsEnabledCheckBoxShouldDisplayAsUnchecked()
        {
            rq05pages = new RQ05_Pages(rq05_Driver);
            Assert.IsFalse(rq05pages._chkBoxIsEnabled.Selected, "IsEnabled check box is checked");
        }

        [Then(@"Is enabled check box should display as checked")]
        public void ThenIsEnabledCheckBoxShouldDisplayAsChecked()
        {
            rq05pages = new RQ05_Pages(rq05_Driver);
            Assert.IsTrue(rq05pages._chkBoxIsEnabled.Selected, "IsEnabled check box is unchecked");
        }


        [When(@"user close the general settings popup page")]
        public void WhenUserCloseTheGeneralSettingsPopupPage()
        {
            rq05_Driver.SwitchTo().DefaultContent();
            rq05pages = new RQ05_Pages(rq05_Driver);
            rq05pages._popUpPageCloseButton.Click();
            //rq05_Driver.SwitchTo().DefaultContent();

        }

        [Then(@"system should not display the general settings popup page")]
        public void ThenSystemShouldNotDisplayTheGeneralSettingsPopupPage()
        {
            rq05pages = new RQ05_Pages(rq05_Driver);
            Console.Write("Here verifying page is closed or not");

            IList<IWebElement> closeButtonElement = rq05_Driver.FindElements(By.XPath("//a[@class='rwCloseButton']"));
            if(closeButtonElement.Count != 0)
            {
                throw new Exception(string.Format("General Settings pop - up is not closed"));
            }
        }

        [Then(@"archived data should not display in the item search grid")]
        public void ThenArchivedDataShouldNotDisplayInTheItemSearchGrid()
        {
            rq05pages = new RQ05_Pages(rq05_Driver);
            rq05pages.ArchivedDataShouldNotDisplayInTheItemSearchGrid();
        }


        [When(@"user navigate to the browser catalog tab to perform the search operation")]
        public void WhenUserNavigateToTheBrowserCatalogTabToPerformTheSearchOperation()
        {
            rq05_Driver.SwitchTo().DefaultContent();
            rq03pages._browseCatalogTab.Click();
        }



        [When(@"click on Archive button and Confirm the message")]
        public void WhenClickOnArchiveButtonAndConfirmTheMessage()
        {
            rq05pages = new RQ05_Pages(rq05_Driver);
            rq05pages._archiveButton.Click();
            rq05_Driver.SwitchTo().Alert().Accept();
        }

        [Then(@"user update the Archived data in the SQL")]
        public void ThenUserUpdateTheArchivedDataInTheSQL()
        {
            string query = "Update WD_WebPackages set Deleted=0 Where PackageTitle='" + RQ05_Pages.selectedTitleText + "'";
            SqlDataReader reader = HooksSpecFlow.connectAppPortal.ExecuteReader(CommandType.Text, query);

            reader.Close();
        }
    }
}
