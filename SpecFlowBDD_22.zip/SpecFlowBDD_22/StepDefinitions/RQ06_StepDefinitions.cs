﻿using OpenQA.Selenium;
using SpecFlowBDD_22.HooksManager;
using SpecFlowBDD_22.Pages;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SpecFlowBDD_22.Framework;
using OpenQA.Selenium.Interactions;
using SpecFlowBDD_22.CommonClass;
using NUnit.Framework;

namespace SpecFlowBDD_22.StepDefinitions
{
    [Binding]
    public class RQ06_StepDefinitions
    {
        public IWebDriver rq06_Driver;
        public static string selectFromList = string.Empty;

        ClassCommon cc = new ClassCommon();
        public RQ06_StepDefinitions(IWebDriver rDriver)
        {
            this.rq06_Driver = rDriver;
            //PageFactory.
        }

        RQ05_Pages rq05pages;
        RQ03_Pages rq03pages;
        RQ06_Pages rq06pages;

        IList<string> sqlDistinctSearchKeywordList = new List<string>();
        IList<IWebElement> lstWebElement = new List<IWebElement>();

        [When(@"user clicks on the search box from the app portal application")]
        public void WhenUserClicksOnTheSearchBoxFromTheAppPortalApplication()
        {
            rq03pages = new RQ03_Pages(rq06_Driver);
            rq03pages._textBoxInputMainSearchCatalog.Click();
        }

        [Then(@"system should display the list of search keyword suggestions based on the past history\(as the logged in user past search keywords\)")]
        public void ThenSystemShouldDisplayTheListOfSearchKeywordSuggestionsBasedOnThePastHistoryAsTheLoggedInUserPastSearchKeywords()
        {
            rq06pages = new RQ06_Pages(rq06_Driver);
            Thread.Sleep(5000);
            IList<string> arrListItems = new List<string>();
            IList<string> sqlSearchKeywordList = new List<string>();
            string userName = cc.getDataFromFile("username");


            IList<IWebElement> lstWebElement = rq06_Driver.FindElements(By.XPath("//li[@class='ui-menu-item']/a[@class='ui-corner-all']"));
            if (lstWebElement.Count > 0)
            {
                foreach (IWebElement element in lstWebElement)
                {
                    Console.WriteLine(element.Text);
                    arrListItems.Add(element.Text);
                }
            }
            else
            {
                throw new Exception(string.Format("Auto Search Suggestions are not displayed"));
            }

            string query = "SELECT Top 10 SearchKeyword, MAX(searchdate) AS searchdate FROM [WD_UserSearchHistory] WHERE SearchDate > DATEADD(DAY, -90, GETDATE())  and UserName="+ userName + " GROUP BY SearchKeyword ORDER BY searchdate DESC";
            
            SqlDataReader reader = HooksSpecFlow.connectAppPortal.ExecuteReader(CommandType.Text, query);

            while (reader.Read())
            {
                string searchKeywordValue = reader["SearchKeyword"].ToString();
                sqlSearchKeywordList.Add(searchKeywordValue);
            }
            sqlSearchKeywordList = sqlSearchKeywordList.OrderBy(x => x.ToString()).ToList();

            for(int i = 0; i < sqlSearchKeywordList.Count; i++)
            {
                if (sqlSearchKeywordList[i].ToLower() != arrListItems[i].ToLower())
                {
                    throw new Exception(string.Format("List of Items not matched"));
                }
            }
            Thread.Sleep(2000);
            reader.Close();
        }

        [Then(@"system should display the list of unique historical search keyword suggestions")]
        public void ThenSystemShouldDisplayTheListOfUniqueHistoricalSearchKeywordSuggestions()
        {
            rq06pages = new RQ06_Pages(rq06_Driver);
            Thread.Sleep(5000);
            List<string> lstItems = new List<string>();

            lstWebElement = rq06_Driver.FindElements(By.XPath("//li[@class='ui-menu-item']/a[@class='ui-corner-all']"));

            foreach(WebElement webElement in lstWebElement)
            {
                lstItems.Add(webElement.Text);
            }

            if (lstItems.Count > 0)
            {
                for(int i=0; i< lstItems.Count; i++)
                {
                    for(int j=i+1; j< lstItems.Count; j++)
                    {
                        string iStr = lstItems[i];
                        string jStr = lstItems[j];
                        if (lstItems[i].ToLower() == lstItems[j].ToLower())
                        {
                            throw new Exception(string.Format("In Auto Search Suggestions List Duplicate Items Found"));
                        }
                    }
                }
            }
            else
            {
                throw new Exception(string.Format("Auto Search Suggestions are not displayed"));
            }
        }

        [When(@"user search by any one search keyword suggestion, which is selected from the list of displayed search keyword suggestions")]
        public void WhenUserSearchByAnyOneSearchKeywordSuggestionWhichIsSelectedFromTheListOfDisplayedSearchKeywordSuggestions()
        {
            rq03pages = new RQ03_Pages(rq06_Driver);
            rq06pages = new RQ06_Pages(rq06_Driver);
            Thread.Sleep(3000);
            Random rnd = new Random();
            Actions act = new Actions(rq06_Driver);
            IList<IWebElement> lstWebElement = rq06_Driver.FindElements(By.XPath("//li[@class='ui-menu-item']/a[@class='ui-corner-all']"));
            

            if (lstWebElement.Count > 0)
            {
                int randomNumber = rnd.Next(1, lstWebElement.Count);
                Console.WriteLine("Random Number: " + randomNumber);
                for (int i = 0; i < lstWebElement.Count; i++)
                {
                    Thread.Sleep(2000);
                    if (i == randomNumber)
                    {
                        selectFromList = lstWebElement[i].Text;
                        Console.WriteLine(selectFromList);
                        lstWebElement[i].Click();
                        rq03pages._textBoxInputMainSearchCatalog.SendKeys(Keys.Enter);
                        break;
                    }
                }
            }
            else
            {
                throw new Exception(string.Format("Auto Search Suggestions are not displayed"));
            }
        }

        [Then(@"the list of unique historical search keyword suggestions should not contain the search keyword which is not searched earlier by him")]
        public void ThenTheListOfUniqueHistoricalSearchKeywordSuggestionsShouldNotContainTheSearchKeywordWhichIsNotSearchedEarlierByHim()
        {
            rq06pages = new RQ06_Pages(rq06_Driver);
            Thread.Sleep(5000);
            IList<string> arrListItems = new List<string>();
            IList<string> sqlSearchKeywordList = new List<string>();

            IList<IWebElement> lstWebElement = rq06_Driver.FindElements(By.XPath("//li[@class='ui-menu-item']/a[@class='ui-corner-all']"));
            if (lstWebElement.Count > 0)
            {
                foreach (IWebElement element in lstWebElement)
                {
                    Console.WriteLine(element.Text);
                    arrListItems.Add(element.Text);
                }
            }
            else
            {
                throw new Exception(string.Format("Auto Search Suggestions are not displayed"));
            }

            string query = "Select distinct SearchKeyword FROM WD_UserSearchHistory Where UserName='APPPORTAL\\Appportal'";
            SqlDataReader reader = HooksSpecFlow.connectAppPortal.ExecuteReader(CommandType.Text, query);

            while (reader.Read())
            {
                string searchKeywordValue = reader["SearchKeyword"].ToString();
                sqlSearchKeywordList.Add(searchKeywordValue);
            }
            sqlSearchKeywordList = sqlSearchKeywordList.OrderBy(x => x.ToString()).ToList();

            for (int i = 0; i < arrListItems.Count; i++)
            {
                if (!sqlSearchKeywordList.Contains(arrListItems[i]))
                {
                    throw new Exception(string.Format("Auto Search Suggestions consist of search keyword which is not searched earlier"));
                }
            }
            reader.Close();
        }

        [Then(@"system should not display the list of unique historical search keyword suggestions as loggin user has not used the search field to search the catalog item")]
        public void ThenSystemShouldNotDisplayTheListOfUniqueHistoricalSearchKeywordSuggestionsAsLogginUserHasNotUsedTheSearchFieldToSearchTheCatalogItem()
        {
            rq06pages = new RQ06_Pages(rq06_Driver);
            Thread.Sleep(5000);
            lstWebElement = rq06_Driver.FindElements(By.XPath("//li[@class='ui-menu-item']/a[@class='ui-corner-all']"));
            if (lstWebElement.Count == 0)
            {
                Console.WriteLine("No search history found for logged user");
            }
            else
            {
                throw new Exception(string.Format("History of logged user displayed"));
            }
        }

        [Then(@"system should not display the search keyword suggestion of different user\(searched by another user/not logged in user\)")]
        public void ThenSystemShouldNotDisplayTheSearchKeywordSuggestionOfDifferentUserSearchedByAnotherUserNotLoggedInUser()
        {
            rq06pages = new RQ06_Pages(rq06_Driver);
            Thread.Sleep(5000);
            IList<string> arrListItems = new List<string>();
            IList<string> sqlSearchKeywordList = new List<string>();

            IList<IWebElement> lstWebElement = rq06_Driver.FindElements(By.XPath("//li[@class='ui-menu-item']/a[@class='ui-corner-all']"));
            if (lstWebElement.Count > 0)
            {
                foreach (IWebElement element in lstWebElement)
                {
                    Console.WriteLine(element.Text);
                    arrListItems.Add(element.Text);
                }
            }
            else
            {
                throw new Exception(string.Format("Auto Search Suggestions are not displayed"));
            }

            string query = "Select distinct SearchKeyword FROM WD_UserSearchHistory";
            SqlDataReader reader = HooksSpecFlow.connectAppPortal.ExecuteReader(CommandType.Text, query);

            while (reader.Read())
            {
                string searchKeywordValue = reader["SearchKeyword"].ToString();
                sqlSearchKeywordList.Add(searchKeywordValue);
            }
            sqlSearchKeywordList = sqlSearchKeywordList.OrderBy(x => x.ToString()).ToList();

            for (int i = 0; i < sqlSearchKeywordList.Count; i++)
            {
                if (sqlSearchKeywordList[i] != arrListItems[i])
                {
                    throw new Exception(string.Format("List of Items not matched"));
                }
            }
            reader.Close();
        }

        [Then(@"user should not be able to see the search keyword of different user")]
        public void ThenUserShouldNotBeAbleToSeeTheSearchKeywordOfDifferentUser()
        {
            rq06pages = new RQ06_Pages(rq06_Driver);
            Thread.Sleep(5000);
            IList<string> arrListItems = new List<string>();
            IList<string> sqlSearchKeywordList = new List<string>();

            IList<IWebElement> lstWebElement = rq06_Driver.FindElements(By.XPath("//li[@class='ui-menu-item']/a[@class='ui-corner-all']"));
            if (lstWebElement.Count > 0)
            {
                foreach (IWebElement element in lstWebElement)
                {
                    Console.WriteLine(element.Text);
                    arrListItems.Add(element.Text);
                }
            }
            else
            {
                throw new Exception(string.Format("Auto Search Suggestions are not displayed"));
            }

            string query = "Select distinct SearchKeyword FROM WD_UserSearchHistory Where UserName != 'APPPORTAL\\Appportal'";
            SqlDataReader reader = HooksSpecFlow.connectAppPortal.ExecuteReader(CommandType.Text, query);

            while (reader.Read())
            {
                string searchKeywordValue = reader["SearchKeyword"].ToString();
                sqlSearchKeywordList.Add(searchKeywordValue);
            }
            sqlSearchKeywordList = sqlSearchKeywordList.OrderBy(x => x.ToString()).ToList();

            for (int i = 0; i < sqlSearchKeywordList.Count; i++)
            {
                if (sqlSearchKeywordList[i].Contains(arrListItems.ToString()))
                    {
                        throw new Exception(string.Format("Auto Search Suggestions displaying other users data"));
                    }
            }
            reader.Close();
        }

        [When(@"user navigate to the User Impersonation page\(Admin >> Site Management >> Active Directory >> User Impersonation\)")]
        public void WhenUserNavigateToTheUserImpersonationPageAdminSiteManagementActiveDirectoryUserImpersonation()
        {
            rq06pages=new RQ06_Pages(rq06_Driver);
            rq06pages.navigateToImpersonationPage();
        }

        [When(@"click on new button")]
        public void WhenClickOnNewButton()
        {
            rq06pages._btnImpersonationNew.Click();
        }

        [Then(@"system should display New Impersonation popup page")]
        public void ThenSystemShouldDisplayNewImpersonationPopupPage()
        {
            rq06pages = new RQ06_Pages(rq06_Driver);
            rq06_Driver.SwitchTo().Frame("Impersonate");
            Assert.AreEqual("Impersonation New", rq06pages._pageImpersonationNew.Text);
        }

        [When(@"user select the account whom they want to impersonate\(whose account they have to access\)")]
        public void WhenUserSelectTheAccountWhomTheyWantToImpersonateWhoseAccountTheyHaveToAccess()
        {
            rq06pages = new RQ06_Pages(rq06_Driver);
            rq06pages._txtBoxImpersonateUser.SendKeys(cc.getDataFromFile("impersonateUser"));
        }

        [When(@"select the current user, click on add selected account")]
        public void WhenSelectTheCurrentUserClickOnAddSelectedAccount()
        {
            rq06pages = new RQ06_Pages(rq06_Driver);
            rq06pages._txtBoxCurrentUserImpersonate.SendKeys(cc.getDataFromFile("currentUserInImpersonate"));
            rq06pages._btnSearchImpersonation.Click();
        }

        [Then(@"the selected user should display in the current account text area")]
        public void ThenTheSelectedUserShouldDisplayInTheCurrentAccountTextArea()
        {
            rq06pages = new RQ06_Pages(rq06_Driver);
            if (rq06pages._txtSearchResult1.Displayed)
            {
                Console.WriteLine("Selected Current user Displaying");
                rq06pages._btnAddSelectedAccount.Click();
                if(rq06pages._txtSearchSelectUser.Displayed)
                {
                    Console.WriteLine("Selected Current Account Displaying");
                }
                else
                {
                    throw new Exception(string.Format("Selected Current Account Not Displaying"));
                }
            }
            else
            {
                throw new Exception(string.Format("Selected Current User Not Displaying"));
            }
        }

        [Then(@"click on save button on New Impersonation popup page")]
        public void ThenClickOnSaveButtonOnNewImpersonationPopupPage()
        {
            rq06pages = new RQ06_Pages(rq06_Driver);
            rq06pages._btnImpersonationSave.Click();
        }

        [When(@"user close the New Impersonation popup page")]
        public void WhenUserCloseTheNewImpersonationPopupPage()
        {
            rq06pages = new RQ06_Pages(rq06_Driver);
            rq06pages._crossCloseButton.Click();
        }

        [Then(@"system should not display the New Impersonation popup page")]
        public void ThenSystemShouldNotDisplayTheNewImpersonationPopupPage()
        {
            rq06pages = new RQ06_Pages(rq06_Driver);

            lstWebElement = rq06_Driver.FindElements(By.XPath("//em[text()='New Impersonation']"));
            if(lstWebElement.Count != 0)
            {
                throw new Exception(string.Format("New Impersonation Page not closed"));
            }
        }



    }
}
